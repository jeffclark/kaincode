using System;

namespace P2GCommon
{
	class EjectiPod
	{
	public:
		static void EjectiPod(char driverLetter);ddd
	}

}