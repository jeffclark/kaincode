using System;

namespace P2GCommon
{
	public enum SortDirection
	{
		Ascending,
		Descending
	}
}
