using System;
using System.Xml;
using System.IO;
using System.Collections;

namespace P2GCommon
{
	public class FeedEntry
	{
		public String title, description, link, date, enclosure, url;

		public override string ToString()
		{
			return title.ToString();
		}
	}

	public class Feed
	{
		XmlDocument document;
		public String title, link, description, url;
		public ArrayList items;
		public bool IsValid;

		public Feed(Stream stream)
		{
			InitXmlDocument(stream);
		}

		public Feed(String filename)
		{
			this.url = filename;
			InitXmlDocument(filename);
		}

		private void InitXmlDocument(object obj)
		{
			try
			{
				document = new XmlDocument();

				if (obj is Stream)
					document.Load((Stream)obj);
				else if (obj is String)
					document.Load((String)obj);

				if (document != null && document.ChildNodes.Count > 0)
				{
					InitFeedItems();
					IsValid = true;
				}
				else
				{
					IsValid = false;
				}
			}
			catch
			{
				IsValid = false;
			}
		}

		private void InitFeedItems()
		{
			XmlNodeList mainNode = document.ChildNodes;
			if (mainNode!=null && mainNode.Count > 0)
			{
				items = new ArrayList();

				// looking for RSS or RDF
				foreach (XmlNode subNode in mainNode)
				{
					if (subNode.Name == "rdf:RDF" || subNode.Name == "rss")
					{
						// looking for Channel
						foreach (XmlNode channelNode in subNode)
						{
							if (channelNode.Name == "channel")
							{
								// looking for Items
								foreach (XmlNode headerNode in channelNode)
								{
									if (headerNode.Name == "title")
									{
										title = headerNode.InnerText;
									}
									else if (headerNode.Name == "description")
									{
										description = headerNode.InnerText;
									}
									else if (headerNode.Name == "link")
									{
										link = headerNode.InnerText;
									}
									else if (headerNode.Name == "item")
									{
										// RSS items
										InitItem(headerNode);
									}
								}
							}
							else if (channelNode.Name == "item")
							{
								// RDF items
								InitItem(channelNode);
							}
						}

						break;
					}
				}
			}
			else
			{
				IsValid = false;
			}

			if (items.Count == 0) IsValid = false;
		}

		private void InitItem(XmlNode theNode)
		{
			FeedEntry feedItem = new FeedEntry();
			
			foreach (XmlNode itemNode in theNode.ChildNodes)
			{
				if (itemNode.Name == "title")
					feedItem.title = itemNode.InnerText;
				else if (itemNode.Name == "link")
					feedItem.link = itemNode.InnerText;
				else if (itemNode.Name == "description")
					feedItem.description = itemNode.InnerText;
				else if (itemNode.Name == "enclosure")
					feedItem.enclosure = itemNode.InnerText;
			}
			items.Add(feedItem);
		}

		public String Format(bool summary, int itemcount)
		{
			System.Text.StringBuilder sb = new System.Text.StringBuilder("");
			int count = 0;
			foreach (FeedEntry entry in this.items)
			{
				if (count == itemcount) break;
				sb.Append(entry.title);
				if (summary) sb.Append("\n" + entry.description.Trim());
				sb.Append("\n----------------------------\n");
				count++;
			}

			return sb.ToString().Trim();
		}
		
	}
}
