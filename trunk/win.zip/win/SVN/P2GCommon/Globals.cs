using System;
using System.Windows.Forms;
using System.Drawing;

namespace P2GCommon
{
	public class Globals
	{
		public static string ApplicationDataDirectory()
		{
			return Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
		}

		public static string Pod2GoDataDirectory()
		{
			return ApplicationDataDirectory() + "\\Pod2Go";
		}
	}
}
