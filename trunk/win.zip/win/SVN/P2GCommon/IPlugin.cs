using System;
using System.Windows.Forms;
using System.Drawing;

namespace P2GCommon
{
	public interface IPlugin
	{
		String Name();
		String AboutInfo();
		Panel GetPanel();
		Bitmap GetImage();
	}
}
