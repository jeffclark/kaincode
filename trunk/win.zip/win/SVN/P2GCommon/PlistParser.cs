using System;
using System.Xml;
using System.IO;
using System.Collections;

namespace P2GCommon
{
	public class PlistParser
	{
		private Object rootObject;

		public PlistParser(string filename)
		{
			FileInfo file = new FileInfo(filename);
			if (file.Exists)
			{
				XmlDocument doc = new XmlDocument();
				doc.Load(file.FullName);
				ParseXmlDocument(doc);
			}
		}

		public PlistParser(Stream stream)
		{
			XmlDocument doc = new XmlDocument();
			doc.Load(stream);
			ParseXmlDocument(doc);
		}

		private void ParseXmlDocument(XmlDocument doc)
		{
			if (doc != null && doc.ChildNodes.Count > 1)
			{
				foreach (XmlNode child in doc.ChildNodes)
				{
					if (child.Name == "plist" && child.ChildNodes.Count == 1)
					{
						XmlNode plistItem = child;
						XmlAttribute version = plistItem.Attributes["version"];
						if (version != null && version.Value == "1.0")
						{
							rootObject = ProcessNode(plistItem.ChildNodes[0]);
						}

						break;
					}
				}
			}		
		}

		private Object ProcessNode(XmlNode node)
		{
			if (node.Name == "dict")
			{
				Hashtable dict = new Hashtable(node.ChildNodes.Count/2);

				string key = null;
				for (int i=0; i<node.ChildNodes.Count; i++)
				{
					XmlNode child = node.ChildNodes[i];
					if (i % 2 == 0 && child.Name == "key")
					{
						key = child.InnerText;
					}
					else
					{
						Object theObject = ProcessNode(child);
						if (key != null)
							dict[key] = theObject;
					}
				}

				return dict;
			}
			else if (node.Name == "array")
			{
				ArrayList array = new ArrayList(node.ChildNodes.Count);
				for (int i=0; i<node.ChildNodes.Count; i++)
				{
					array.Add(ProcessNode(node.ChildNodes[i]));
				}
				return array;
			}
			else if (node.Name == "integer")
			{
				return Convert.ToInt32(node.InnerText);
			}
			else if (node.Name == "string")
			{
				return node.InnerText;
			}
			else if (node.Name == "true")
			{
				return true;
			}
			else if (node.Name == "false")
			{
				return false;
			}

			return null;
		}

		public Object RootObject
		{
			get { return rootObject; }
		}
	}
}
