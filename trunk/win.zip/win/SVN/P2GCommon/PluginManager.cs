using System;
using System.Collections;
using System.Reflection;
using System.IO;
using System.Windows.Forms;

namespace P2GCommon
{
	/// <summary>
	/// Summary description for PluginManager.
	/// </summary>
	public class PluginManager
	{
		private ArrayList plugins;

		public PluginManager()
		{
			plugins = new ArrayList();

			try
			{
				string[] paths = {Application.StartupPath};// + @"\Plugins"};

				foreach (string path in paths)
				{
					foreach (string dll in Directory.GetFiles(path))
					{
						if (dll.EndsWith("dll"))
						{
							try
							{
								Assembly assm = Assembly.LoadFile(dll);
								foreach (Type type in assm.GetTypes())
								{
									if (type.GetInterface("IPlugin") != null)
									{
										//IPlugin iPlugin = (IPlugin)type;
										//Console.WriteLine("Type: {0}", type.ToString());
										Plugin plug = new Plugin(type, dll);
										plugins.Add(plug);
									}
								}
							}
							catch (Exception exception)
							{
								Console.WriteLine("Can't load file: {0}", dll);
								Console.WriteLine(exception.Message);
							}
						}
					}
				}
			} 
			catch (Exception exception)
			{
				Console.WriteLine("PluginManager: {0}", exception.Message);
			}
		}

		public ArrayList GetPlugins()
		{
			return plugins;
		}
	}
}
