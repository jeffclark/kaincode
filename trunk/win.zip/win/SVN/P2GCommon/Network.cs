using System;
using System.Runtime.InteropServices;

namespace P2GCommon
{
	public class Network
	{
		// code from http://www.experts-exchange.com/Programming/Programming_Languages/C_Sharp/Q_21060634.html

		[Flags]
			enum InternetGetConnectedStateFlags
		{
			INTERNET_CONNECTION_MODEM = 0x01,
			INTERNET_CONNECTION_LAN = 0x02,
			INTERNET_CONNECTION_PROXY = 0x04,
			INTERNET_CONNECTION_RAS_INSTALLED = 0x10,
			INTERNET_CONNECTION_OFFLINE = 0x20,
			INTERNET_CONNECTION_CONFIGURED = 0x40
		}

		[DllImport("wininet.dll", SetLastError=true)]
		extern static bool InternetGetConnectedState(out InternetGetConnectedStateFlags Description, int ReservedValue);

		public static bool ConnectedToInternet()
		{
			InternetGetConnectedStateFlags fl = new InternetGetConnectedStateFlags();
			if (InternetGetConnectedState(out fl, 0))
				return true;
			return false;
		}
	}
}
