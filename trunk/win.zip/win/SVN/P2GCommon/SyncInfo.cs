using System;

namespace P2GCommon
{
	public class SyncInfo
	{
		public delegate void PluginSyncComplete();
		public event PluginSyncComplete OnPluginSyncComplete;

		public delegate void PluginItemStatus(string obj);
		public event PluginItemStatus OnPluginItemStatus;

		private iPod ipod;
		private SyncLog syncLog;
		private bool connectedToInternet;

		public SyncInfo(iPod iPod, SyncLog syncLog)
		{
			this.ipod = iPod;
			this.syncLog = syncLog;
			this.connectedToInternet = true;
		}

		public SyncInfo(iPod iPod, SyncLog syncLog, bool connected2Internet)
		{
			this.ipod = iPod;
			this.syncLog = syncLog;
			this.connectedToInternet = connected2Internet;
		}

		public iPod iPodSynced
		{
			get { return ipod; }
		}

		public SyncLog SyncLog
		{
			get { return syncLog; }
		}

		public bool ConnectedToInternet
		{
			get { return connectedToInternet; }
		}

		public void ReportSyncComplete()
		{
			if (OnPluginSyncComplete != null)
				OnPluginSyncComplete();
		}

		public void UpdateItemStatus(string status)
		{
			if (OnPluginItemStatus != null)
				OnPluginItemStatus(status);
		}
	}
}
