using System;
using System.Windows.Forms;
using System.Reflection;
using System.Drawing;

namespace P2GCommon
{
	/// <summary>
	/// Summary description for Plugin.
	/// </summary>
	public class Plugin
	{
		private String filePath;
		private Type plugType;
		private IPlugin plugInstance;

		public Plugin(Type type, String path)
		{
			try
			{
				filePath = path;

				plugType = type;
				plugInstance = (IPlugin)Activator.CreateInstance(type);
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}

		public String Name()
		{
			/*if (name == null)
				name = (String)plugType.InvokeMember("Name",
					BindingFlags.Default | BindingFlags.InvokeMethod,
					null,
					plugInstance,
					null);

			return name;*/
			return plugInstance.Name();
		}

		public String AboutInfo()
		{
			/*if (aboutInfo == null)
				aboutInfo = (String)plugType.InvokeMember("AboutInfo",
					BindingFlags.Default | BindingFlags.InvokeMethod,
					null,
					plugInstance,
					null);

			return aboutInfo;*/
			return plugInstance.AboutInfo();
		}

		public Panel GetPanel()
		{
			/*if (panel == null)
				panel = (Panel)plugType.InvokeMember("GetPanel",
					BindingFlags.Default | BindingFlags.InvokeMethod,
					null,
					plugInstance,
					null);

			return panel;*/
			return plugInstance.GetPanel();
		}

		public Bitmap GetImage()
		{
			/*if (image == null)
				image = (Bitmap)plugType.InvokeMember("GetImage",
					BindingFlags.Default | BindingFlags.InvokeMethod,
					null,
					plugInstance,
					null);

			return image;*/
			return plugInstance.GetImage();
		}

		public void OnPluginLoad()
		{
			try
			{
				System.Reflection.MemberInfo[] m = plugType.GetMember("OnPluginLoad");
				if (m != null && m.Length > 0)
				{
					plugType.InvokeMember("OnPluginLoad",
						BindingFlags.Default | BindingFlags.InvokeMethod,
						null,
						plugInstance,
						null);
				}
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}

		public bool Sync(SyncInfo syncInfo)
		{
			try
			{
				plugType.InvokeMember("Sync",
					BindingFlags.Default | BindingFlags.InvokeMethod,
					null,
					plugInstance,
					new object[]{syncInfo});
				return true;
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
			}

			return false;
		}

		public void CancelSync()
		{
			try
			{
				plugType.InvokeMember("CancelSync",
					BindingFlags.Default | BindingFlags.InvokeMethod,
					null,
					plugInstance,
					null);
			}
			catch (Exception ex)
			{
				throw new Exception("An exception occurred cancelling the sync.", ex);
			}
		}

		public override string ToString()
		{
			return plugInstance.Name();
		}
	}
}
