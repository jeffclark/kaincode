using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace P2GCommon
{
	public class SyncLog
	{
		private RichTextBox rtb;
		private string newline = "\r\n";
		private DateTime startingDate;
		private Font systemFont;

		public SyncLog()
		{
			rtb = new RichTextBox();
			rtb.Multiline = true;
			startingDate = DateTime.Now;
			systemFont = new Font("System", 10);
		}

		public void AppendLog(string log)
		{
			Append(log, Color.Black, systemFont);
		}

		public void AppendTool(string log)
		{
			Append(newline + log, Color.Blue, new Font("System", 14, FontStyle.Bold));
		}

		public void AppendEntry(string log)
		{
			Append(log, Color.Black, new Font("System", 10, FontStyle.Bold));
		}

		public void AppendError(string log)
		{
			Append(log, Color.Red, systemFont);
		}

		private void Append(string log, Color color, Font font)
		{
			rtb.AppendText(newline + log);
			string[] lines = rtb.Lines;
			rtb.SelectionStart = rtb.Find(lines[lines.Length-1], RichTextBoxFinds.Reverse);
			//rtb.SelectionStart = rtb.Find(newline, System.Windows.Forms.RichTextBoxFinds.Reverse | 
			//	System.Windows.Forms.RichTextBoxFinds.NoHighlight) + 1;
			rtb.SelectionLength = log.Length;

			rtb.SelectionColor = color;
			rtb.SelectionFont = font;
		}

		public DateTime StartingDate
		{
			get { return startingDate; }
		}

		public void WriteToFile()
		{
			try
			{
				string logsFolder = Globals.Pod2GoDataDirectory() + "\\Logs";
				string logPath = logsFolder + "\\" + startingDate.ToFileTime().ToString() + ".rtf";

				if (!Directory.Exists(logsFolder)) Directory.CreateDirectory(logsFolder);
				rtb.SaveFile(logPath, System.Windows.Forms.RichTextBoxStreamType.RichText);
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}
	}
}
