using System;
using System.Net;
using System.Collections;
using System.IO;
using System.Windows.Forms;

namespace P2GCommon
{
	public class Downloader
	{
		public delegate void OnDownloadComplete();
		public event OnDownloadComplete DownloadComplete;
		private WebRequest webRequest;
		private bool downloading;
		private string stringData;
		private Stream streamData;

		/* static methods */
		public static String GetString(String url)
		{
			try
			{
				HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
				HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
				Stream stream = resp.GetResponseStream();
				System.Text.Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
				StreamReader readStream = new StreamReader(stream, encode);
				Char[] read = new Char[256];
				int count = readStream.Read( read, 0, 256 );
				String temp = new String("".ToCharArray());
				while (count > 0) 
				{
					String str = new String(read, 0, count);
					temp += str;
					count = readStream.Read(read, 0, 256);
				}
				resp.Close();
				stream.Close();

				return temp;
			}
			catch (Exception ex)
			{
				throw new Exception("An exception was thrown while downloading.", ex);
			}
		}

		public static Stream GetStream(String url)
		{
			try
			{
				HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
				HttpWebResponse resp = (HttpWebResponse)req.GetResponse();

				if (resp.StatusCode == System.Net.HttpStatusCode.OK)
				{
					Stream stream = resp.GetResponseStream();
					return stream;
				}
				else
				{
					return null;
				}
			}
			catch (Exception ex)
			{
				throw new Exception("An exception was thrown while downloading.", ex);
			}
		}

		public Downloader()
		{
			downloading = false;
		}

		public bool IsDownloading
		{
			get { return downloading; }
		}

		public void Load(string url)
		{
			downloading = true;
			stringData = null;
			streamData = null;

			webRequest = WebRequest.Create(url);
			webRequest.Timeout = 15;
			webRequest.BeginGetResponse(new AsyncCallback(DLComplete), webRequest);
		}

		public void Cancel()
		{
			webRequest.Abort();
			downloading = false;
		}

		private void DLComplete(IAsyncResult result)
		{
			try
			{
				WebRequest request = (WebRequest)result.AsyncState;
				WebResponse response = request.EndGetResponse(result);
				Stream stream = response.GetResponseStream();
				streamData = stream;				
				downloading = false;
				
				if (DownloadComplete != null)
					DownloadComplete();
			}
			catch (Exception exception)
			{
				Console.WriteLine("Downloader: {0}", exception.Message);

				if (DownloadComplete != null)
					DownloadComplete();
			}
		}

		private void SetStringData()
		{
			StreamReader sr = new StreamReader(this.StreamData, System.Text.Encoding.GetEncoding("UTF-8"));
			string text = sr.ReadToEnd();
			this.stringData = text.Trim();
		}

		public string StringData
		{			
			get { SetStringData(); return stringData; }
		}

		public Stream StreamData
		{
			get { return streamData; }
		}
	}
}
