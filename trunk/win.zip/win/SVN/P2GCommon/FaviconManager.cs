using System;
using System.Drawing;
using System.IO;
using System.Collections;

namespace P2GCommon
{
	public class FaviconManager
	{
		private string faviconFolder;
		private SharedImages sharedImages;
		private Hashtable favicons;
		private bool err;

		public FaviconManager()
		{
			try
			{
				err = false;
				faviconFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"\Pod2Go\Favicons";
				sharedImages = new SharedImages();
				favicons = new Hashtable();

				if (!Directory.Exists(faviconFolder))
					Directory.CreateDirectory(faviconFolder);

				// load all favicons from file
				DirectoryInfo d = new DirectoryInfo(faviconFolder);
				foreach (FileInfo f in d.GetFiles())
				{
					if (f.Extension.Equals(".bmp"))
					{
						string fullPath = f.FullName;
						string host = f.Name.Replace(".bmp", "");
						Bitmap b = new Bitmap(fullPath);
						if (b != null)
							favicons[host] = b;
					}
				}
			}
			catch (Exception ex)
			{
				throw new Exception("An exception was thrown while creating a new FaviconManager.", ex);
			}
		}

		public Bitmap GetFavicon(string url)
		{
			if (err) return null;

			try
			{
				System.Uri uri = new Uri(url);
				if (uri != null)
				{
					string host = uri.Host;
					return (Bitmap)favicons[host];
				}
				else
					return null;
			}
			catch (Exception ex)
			{
				throw new Exception("An exception was thrown getting the favicon.", ex);
			}

		}

		public Bitmap LoadFavicon(string url)
		{
			if (err) return null;

			try
			{
				System.Uri uri = new Uri(url);
				if (uri != null)
				{
					string host = uri.Host;
					if (favicons[host] == null)
					{
						string faviconPath = faviconFolder + "/" + host + ".bmp";

						string faviconUrl = "http://" + host + "/favicon.ico";
						Stream s = Downloader.GetStream(faviconUrl);
						if (s!= null)
						{
							Bitmap b = new Bitmap(s);
							if (b != null)
							{
								b.Save(faviconPath);
								favicons[host] = b;
							}
						}
					}
					
					return (Bitmap)favicons[host];
				}
				else
					return null;
			}
			catch
			{
				//throw new Exception("An exception was thrown loading the icon.", ex);
				return null;
			}

		}
	}
}
