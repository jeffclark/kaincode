using System;
using System.Drawing;
using System.Reflection;
using System.IO;

namespace P2GCommon
{
	public class SharedImages
	{
		private Bitmap smallGlobe;

		public SharedImages()
		{
		}

		public Bitmap SmallGlobe
		{
			get
			{
				if (smallGlobe == null)
				{
					Assembly assembly = Assembly.GetAssembly(this.GetType());
					Stream s = assembly.GetManifestResourceStream("P2GCommon.Images.globe.gif");
					if (s != null)
					{
						smallGlobe = new Bitmap(s);
					}
				}

				return smallGlobe;
			}
		}
	}
}
