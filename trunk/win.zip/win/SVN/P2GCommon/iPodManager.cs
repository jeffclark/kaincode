using System;
using System.Collections;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace P2GCommon
{
	public class iPodManagerEventArgs : EventArgs
	{
		public iPod iPod;

		public iPodManagerEventArgs(iPod iPod)
		{
			this.iPod = iPod;
		}
	}

	public class iPodManager
	{
		public delegate void iPodConnectHandler (object sender, iPodManagerEventArgs eventArgs);
		public event iPodConnectHandler iPodConnect;
		
		private DeviceVolumeMonitor vMonitor;
		//private DeviceEventNotifier eventNot;

		public iPodManager(System.IntPtr windowHandle)
		{
			// http://www.codeproject.com/dotnet/devicevolumemonitor.asp
			vMonitor = new DeviceVolumeMonitor(windowHandle);
			vMonitor.OnVolumeInserted += new DeviceVolumeAction(vMonitor_OnVolumeInserted);

			//eventNot = new DeviceEventNotifier();
			//eventNot.DeviceEvent += new P2GCommon.DeviceEventNotifier.DeviceEventHandler(eventNot_DeviceEvent);
		}

		// util function
		private void iPodConnected(char DriveLetter)
		{
			iPod pod = new iPod(DriveLetter);
			//MessageBox.Show(DriveLetter.ToString() + " - iPod exists? " + pod.Exists().ToString());
			
			if (pod.Exists())
				iPodConnect(this, new iPodManagerEventArgs(pod));
		}

		private void vMonitor_OnVolumeInserted(int aMask)
		{
			// convert string (P:) to char
			char driveLetter = Convert.ToChar(vMonitor.MaskToLogicalPaths(aMask).Substring(0, 1));
			iPodConnected(driveLetter);
		}

		/*private void eventNot_DeviceEvent(char DriveLetter, DeviceEventNotifier.DeviceEventType EventType)
		{
			if (EventType == DeviceEventNotifier.DeviceEventType.Connect && iPodConnect != null)
			{
				iPodConnected(DriveLetter);
			}
		}*/

	}

	/*public class DeviceEventNotifier : System.Windows.Forms.Form
	{
		// http://www.dotnet247.com/247reference/msgs/43/217435.aspx

		public enum DeviceEventType
		{
			Connect,
			Disconnect
		}

		public delegate void DeviceEventHandler(char DriveLetter, DeviceEventType EventType);
		public event DeviceEventHandler DeviceEvent;

		public delegate int MyWindowProcDelegate(int hwnd, int Msg, int wParam, int lParam);
		public event MyWindowProcDelegate Delly;

		[DllImport("user32.dll", EntryPoint = "CallWindowProcA")]
		public static extern int CallWindowProc(int lpPrevWndFunc, int hwnd, int Msg, int wParam, int lParam);
		
		[DllImport("user32.dll", EntryPoint = "GetWindowLongA")]
		public static extern int GetWindowLong(int hwnd, int nIndex);

		[DllImport("user32.dll", EntryPoint = "SetWindowLongA")]
		public static extern int SetWindowLong(int hwnd, int nIndex, MyWindowProcDelegate dwNewLong);

		const int GWL_WNDPROC = -4;
		const int WM_DEVICECHANGE = 0x219;

		const int UNSAFE_REMOVE = 0x1C;
		const int DBT_DEVICEARRIVAL = 0x8000; // system detected a new device
		const int DBT_DEVTYP_VOLUME = 0x00000002; // logical volume
		const int DBT_DEVICEREMOVECOMPLETE = 0x8004;

		int glngPrevWndProc;

		[StructLayout(LayoutKind.Sequential)]
			public struct DEV_BROADCAST_VOLUME
		{
			public int dbcv_size;
			public int dbcv_devicetype;
			public int dbcv_reserved;
			public int dbcv_unitmask;
		}

		public DeviceEventNotifier() : base()
		{
			Delly += new MyWindowProcDelegate(MyWindowProc);

			glngPrevWndProc = GetWindowLong(Handle.ToInt32(), GWL_WNDPROC);
			SetWindowLong(Handle.ToInt32(), GWL_WNDPROC, Delly);
		}

		public int MyWindowProc(int hwnd, int Msg, int wParam, int lParam)
		{
			if (Msg == WM_DEVICECHANGE)
			{
				switch (wParam)
				{
					case DBT_DEVICEARRIVAL:
						//MessageBox.Show("Device arrival!");
						if (DeviceEvent != null)
							DeviceEvent(GetDriveLetter(lParam), DeviceEventType.Connect);
						break;

					case DBT_DEVICEREMOVECOMPLETE:
						//MessageBox.Show("Device removal!");
						if (DeviceEvent != null)
							DeviceEvent(GetDriveLetter(lParam), DeviceEventType.Disconnect);
						break;
				}

				return 0;
			}

			return CallWindowProc(glngPrevWndProc, hwnd, Msg, wParam, lParam);
		}

		private char GetDriveLetter(int LParam)
		{
			char d;
			int i;
			int devType = Marshal.ReadInt32(LParam,4);
			
			DEV_BROADCAST_VOLUME vol = (DEV_BROADCAST_VOLUME)
				Marshal.PtrToStructure(new IntPtr(LParam), typeof(DEV_BROADCAST_VOLUME));

			int unitmask = vol.dbcv_unitmask;

			for (i=0; i<26; ++i)
			{
				if ((unitmask & 0x1) != 0)
					break;
				unitmask = unitmask >> 1;
			}
			d =  (char)(i + (int)'A');

			return d;
			//MessageBox.Show("ascii: " + new string(d, 1));
		}
	}*/
}
