using System;
using System.Text;

namespace P2GCommon
{
	/// <summary>
	/// Summary description for StringUtils.
	/// </summary>
	public class StringUtils
	{
		// basic way, works only with simple html.
		public static string StripHTMLSimple(string html)
		{
			int len = html.Length;
			StringBuilder s = new StringBuilder(len);
			int i, level=0;

			for (i=0; i<len; i++)
			{
				string ch = html.Substring(i, 1);

				if (ch == "<")
					level++;
				else if (ch == ">")
				{
					level--;

					if (level == 0)
						s.Append("");
				}
				else if (level == 0)
					s.Append(ch);
			}

			return s.ToString();
		}

		public static string SingleSpace(string input)
		{
			while (input.IndexOf("  ") != -1)
				input = input.Replace("  ", " ");
			return input;
		}
	}
}
