using System;
using System.Xml;
using System.Collections;
using System.IO;
using System.Data;
using System.Windows.Forms;

namespace P2GCommon
{
	public class Prefs
	{
		private String name;
		private String filePath;

		public XmlDocument xmlDoc;

		public Prefs(String pluginName)
		{
			name = pluginName;
			filePath = Globals.Pod2GoDataDirectory() + "\\" + pluginName + ".xml";

			xmlDoc = new XmlDocument();
			if (new FileInfo(filePath).Exists)
			{
				try
				{
					xmlDoc.Load(filePath);
					return;
				}
				catch (Exception e)
				{
					Console.WriteLine(e.Message);
				}
			}

			Directory.CreateDirectory(Globals.Pod2GoDataDirectory());

			XmlDeclaration decl = xmlDoc.CreateXmlDeclaration("1.0", "UTF-8", "");
			XmlElement prefs = xmlDoc.CreateElement("prefs");
			xmlDoc.AppendChild(decl);
			xmlDoc.AppendChild(prefs);
			//xmlDoc.Save(filePath);
		}

		public void WriteToFile()
		{
			XmlWriter writer = new XmlTextWriter(filePath, System.Text.Encoding.UTF8);
			xmlDoc.WriteContentTo(writer);
			writer.Close();
		}

		public void SetString(string obj, string key)
		{
			XmlNode e = ReadNode(key);
			e.InnerText = obj;
			//xmlDoc.DocumentElement.AppendChild(e);
		}

		public String GetString(string key, string defaultValue)
		{
			foreach (XmlNode node in xmlDoc.DocumentElement.ChildNodes)
			{
				if (node.Name == key)
				{
					return node.InnerText;
				}
			}

			// nothing found. return default value
			return defaultValue;
		}

		public void WriteElement(XmlElement e)
		{
			if (e != null)
			{
				xmlDoc.DocumentElement.AppendChild(e);
			}
		}

		public XmlNode ReadNode(String name)
		{
			foreach (XmlNode node in xmlDoc.DocumentElement.ChildNodes)
			{
				if (node.Name == name)
				{
					return node;
				}
			}

			XmlElement e = xmlDoc.CreateElement(name);
			xmlDoc.DocumentElement.AppendChild(e);

			return e;
		}

		public ArrayList ReadAll(String key)
		{
			ArrayList temp = new ArrayList();
			foreach (XmlNode node in xmlDoc.DocumentElement.ChildNodes)
			{
				if (node.Name == key)
				{
					temp.Add(node.InnerText);
				}
			}

			return temp;
		}

		/* Forms */
		public String GetFormPosition(string formName)
		{
			foreach (XmlNode node in xmlDoc.DocumentElement.ChildNodes)
				if (node.Name == formName)
					return node.InnerText;

			return null;
		}

		public void SetFormPosition(string position, string formName)
		{
			XmlNode node = ReadNode(formName);
			node.InnerText = position;

			WriteToFile();
		}
	}
}
