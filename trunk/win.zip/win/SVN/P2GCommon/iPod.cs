using System;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

namespace P2GCommon
{
	public class iPod
	{
		private string iPodPath;
		private bool useNotes;
		private bool useP2GFolder;
		private string driveLetter;
		//private string name;
	
		public iPod()
		{
			try
			{
				foreach (string drive in Environment.GetLogicalDrives())
				{
					// skip A drives
					if (drive[0] != 'A' && drive[0] != 'a')
					{
						String iPodControlPath = drive + "iPod_Control";
						if (Directory.Exists(iPodControlPath))
						{
							iPodPath = drive;
							driveLetter = new string(drive[0], 1);
							this.SetupUseNotes();

							break;
						}
					}
				}
			
				// TODO: load P2GFolder option from prefs
				useP2GFolder = true;
			}
			catch (Exception ex)
			{
				throw new Exception("An exception was thrown creating a new iPod instance.", ex);
			}
		}

		public iPod(char DriveLetter)
		{
			try
			{
				String drive = new String(DriveLetter, 1) + @":\";
				String iPodControlPath = drive + "iPod_Control";
				if (Directory.Exists(iPodControlPath))
				{
					iPodPath = drive;
					driveLetter = new string(DriveLetter, 1);
					this.SetupUseNotes();
				}
			}
			catch (Exception ex)
			{
				throw new Exception("An exception was thrown creating a new iPod instance.", ex);
			}
		}
		
		public string DriveLetter
		{
			get { return driveLetter; }
		}

		public bool Exists()
		{
			return Directory.Exists(iPodPath);
		}
		
		public String Name
		{
			get { return iPodPath; }
		}
		
		public String FullPath
		{
			get { return iPodPath; }
		}
		
		public String NotesFolder
		{
			get { return iPodPath + @"Notes\"; }
		}

		public String Pod2GoFolder
		{
			get
			{
				if (useP2GFolder)
					return this.NotesFolder + @"Pod2Go\";
				return this.NotesFolder;
			}
		}
				
		public String ContactsFolder
		{
			get { return iPodPath + @"Contacts\"; }
		}

		public String CalendarsFolder
		{
			get { return iPodPath + @"Calendars\"; }
		}

		public bool isiPodShuffle
		{
			get
			{
				FileInfo iTunesShuffle = new FileInfo(iPodPath + @"iPod_Control\iTunes\iTunesShuffle");
				FileInfo iTunesSD = new FileInfo(iPodPath + @"iPod_Control\iTunes\iTunesSD");
				return (iTunesShuffle.Exists || iTunesSD.Exists);
			}
		}
		
		public int NotesCount
		{
			get
			{
				String notesPath = this.NotesFolder;
				DirectoryInfo notesFolder = new DirectoryInfo(notesPath);
			
				if (notesFolder.Exists)
					return this.NotesInDirectory(new DirectoryInfo(notesPath));

				return 0;
			}
		}
		
		private int NotesInDirectory(DirectoryInfo dir)
		{
			try
			{
				int count = 0;

				if (dir != null && dir.Exists)
				{
					FileSystemInfo[] files = dir.GetFileSystemInfos();
					foreach (FileSystemInfo file in files)
					{
						if (!file.Name.StartsWith("."))
						{
							DirectoryInfo testDir = new DirectoryInfo(file.FullName);
							if (testDir.Exists)
							{
								count += this.NotesInDirectory(new DirectoryInfo(file.FullName));
							}
							else
							{
								count++;
							}
						}
					}
				
				}
				return count;
			}
			catch (Exception ex)
			{
				throw new Exception("An exception occurred while counting notes.", ex);
			}
		}
		
		public bool UseNotes
		{
			get
			{
				return useNotes;
			}
		}
		
		private void SetupUseNotes()
		{
			if (this.Exists())
			{
				FileInfo sysInfo = new FileInfo(this.FullPath + @"iPod_Control\Device\SysInfo");
				if (sysInfo.Exists)
				{
					StreamReader file = new StreamReader(sysInfo.FullName);
					String line;
					while ((line = file.ReadLine()) != null)
					{
						if (line.StartsWith("buildID:"))
						{
							String[] words =  line.Split(" ".ToCharArray());
							if (words.Length == 3)
							{
								String v = words[2].Replace("(", "").Replace(")", "").Substring(0, 1);
								double vers = Convert.ToDouble(v);
								if (vers >= 2)
								{
									useNotes = true;
									break;
								}
							}
						}
					}
					file.Close();
					return;
				}
			}
			
			useNotes = false;
		}
		
		public bool Eject()
		{
			try
			{
				StreamReader outputStream;
				String output;
				Process ejectVolume = new Process();

				ejectVolume.StartInfo.FileName = "deveject.exe";
				ejectVolume.StartInfo.UseShellExecute = false;
				ejectVolume.StartInfo.CreateNoWindow = true;
				ejectVolume.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
				ejectVolume.StartInfo.RedirectStandardOutput = true;
				ejectVolume.StartInfo.RedirectStandardError = true;
				ejectVolume.StartInfo.WorkingDirectory = Application.StartupPath;
				// deveject.exe -EjectDrive:P:
				ejectVolume.StartInfo.Arguments = "-EjectDrive:" + this.DriveLetter + ":";
				
				ejectVolume.Start();
				ejectVolume.WaitForExit();

				outputStream = ejectVolume.StandardOutput;
				output = outputStream.ReadToEnd();

				ejectVolume.Close();

				// this text will appear in the output if deveject _thinks_ it ejected the
				// ipod. but if the ipod is in use, deveject won't notice and still returns
				// success, so we have to manually determine if the ipod exists still anyways
				if (output.IndexOf("1 device(s) ejected") == -1)
					return false;

				if (!this.Exists())
					return true;

				//MessageBox.Show(output);
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}

			return false;
		}

		public void RemoveNotesDirectory(string name)
		{
			string path1 = this.NotesFolder + name, path2 = this.NotesFolder + @"Pod2Go\" + name;
			if (Directory.Exists(path1)) Directory.Delete(path1, true);
			if (Directory.Exists(path2)) Directory.Delete(path2, true);
		}
		
		public bool CreateNote(String note, String title, String localPath)
		{
			String newTitle = title;
			String xmlTitle = "<title>" + newTitle + "</title>";
			String newNote = xmlTitle + note;
			String fileName = (newTitle.EndsWith(".txt") ? newTitle : newTitle + ".txt");
			String newLocalPath = (localPath.StartsWith("/") ? localPath : "/"+localPath);
			
			String noteDirectory = this.Pod2GoFolder + "/" + newLocalPath;
			String notePath = noteDirectory + "/" + fileName;
			
			if (!Directory.Exists(this.NotesFolder)) Directory.CreateDirectory(this.NotesFolder);
			if (!Directory.Exists(this.Pod2GoFolder)) Directory.CreateDirectory(this.Pod2GoFolder);
			if (!Directory.Exists(noteDirectory)) Directory.CreateDirectory(noteDirectory);

			if (newNote.Length + xmlTitle.Length <= 4096)
			{
				try
				{
					StreamWriter str = File.CreateText(notePath);
					str.Write(newNote);
					str.Close();
				}
				catch (Exception e)
				{
					Console.WriteLine(e.Message);
				}
			}

			return (File.Exists(notePath));
		}

		public override string ToString()
		{
			return String.Format("{0} ({1})", this.Name, this.FullPath);
		}

	}
}