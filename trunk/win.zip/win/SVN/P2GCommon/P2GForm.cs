using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace P2GCommon
{
	public class P2GForm : System.Windows.Forms.Form
	{
		private System.ComponentModel.Container components = null;

		public string GetPosition()
		{
			return this.Left.ToString() + " " + this.Top.ToString() + " " + this.Width.ToString() + " " + this.Height.ToString();
		}

		public void SetPosition(string position)
		{
			if (position != null)
			{
				string[] parts = position.Split(" ".ToCharArray());
				if (parts.Length == 4)
				{
					int x, y, w, h;
					x = Convert.ToInt32(parts[0]);
					y = Convert.ToInt32(parts[1]);
					w = Convert.ToInt32(parts[2]);
					h = Convert.ToInt32(parts[3]);
					
					this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
					this.Location = new Point(x, y);
					this.Size = new Size(w, h);
				}
			}
		}

		public P2GForm()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// P2GForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 271);
			this.Name = "P2GForm";
			this.Text = "SavePositionForm";
			this.Load += new System.EventHandler(this.P2GForm_Load);

		}
		#endregion

		private void P2GForm_Load(object sender, System.EventArgs e)
		{
		
		}
	}
}
