DevEject -- Ger�te automatisch abmelden, f�r Windows 2000/XP/2003
=================================================================


DevEject dient dazu, externe Speicherger�te wie FireWire-Platten oder
USB-Sticks programmgesteuert beim Betriebssystem abzumelden.

Eine n�here Beschreibung finden Sie in c't 16/03, S. 208.


DevEject.exe -- das ausf�hrbare Programm
DevEject.cpp -- Quelltext in C++

