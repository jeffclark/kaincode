using System;
using System.Xml;
using System.Collections;

namespace BiblePod
{
	public class BibleBook
	{
		private String name;
		private int chapterCount;
		private XmlNode node;

		public BibleBook(String name, XmlNode node)
		{
			this.name = name;
			this.node = node;

			chapterCount = 0;
			for (int i=0; i<node.ChildNodes.Count; i++)
			{
				if (node.ChildNodes[i].Name == "CHAPTER")
					chapterCount++;
			}
		}

		public String Name
		{
			get { return name; }
		}

		public int ChapterCount
		{
			get { return chapterCount; }
		}

		public ArrayList Chapter(int index)
		{
			ArrayList temp = new ArrayList();
			for (int i=0; i<node.ChildNodes.Count; i++)
			{
				if (i == index)
				{
					for (int j=0; j<node.ChildNodes[i].ChildNodes.Count; j++)
					{
						temp.Add(node.ChildNodes[i].ChildNodes[j].InnerText);
					}
				}
			}
			return temp;
		}

		public override string ToString()
		{
			return name.ToString();
		}

	}
}
