using System;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

namespace BiblePod
{
	public class iPod
	{
		private DirectoryInfo theiPod;
		private bool useNotes;
		private string driveLetter;
	
		public iPod()
		{
			foreach (string drive in Environment.GetLogicalDrives())
			{
				// skip A drives
				if (drive[0] != 'A' && drive[0] != 'a')
				{
					String iPodControlPath = drive + "iPod_Control";
					if (Directory.Exists(iPodControlPath))
					{
						theiPod = new DirectoryInfo(drive);
						driveLetter = new string(drive[0], 1);
						this.SetupUseNotes();

						break;
					}
				}
			}
		}

		public string DriveLetter
		{
			get
			{
				return driveLetter;
			}
		}

		public bool Exists()
		{
			return !(theiPod == null);
		}
		
		public String Name
		{
			get
			{
				if (this.Exists())
				{
					return theiPod.Name;
				}
			
				return null;
			}
		}
		
		public String FullPath
		{
			get
			{
				return theiPod.FullName;
			}
		}
		
		public String NotesFolder
		{
			get
			{
				return theiPod.FullName + @"Notes";
			}
		}

		public String BiblePodFolder
		{
			get
			{
				return this.NotesFolder + @"\Bible";
			}
		}
		
		public String BiblePodFilesFolder
		{
			get
			{
				return this.BiblePodFolder + @"\files";
			}
		}

		public int NotesCount
		{
			get
			{
				if (this.Exists())
				{
					String notesPath = theiPod.FullName + "/Notes";
					DirectoryInfo notesFolder = new DirectoryInfo(notesPath);
				
					if (notesFolder.Exists)
					{
						return this.NotesInDirectory(new DirectoryInfo(notesPath));
					}
				}
			
				return 0;
			}
		}
		
		private int NotesInDirectory(DirectoryInfo dir)
		{
			int count = 0;

			if (dir != null && dir.Exists)
			{
				FileSystemInfo[] files = dir.GetFileSystemInfos();
				foreach (FileSystemInfo file in files)
				{
					if (!file.Name.StartsWith("."))
					{
						DirectoryInfo testDir = new DirectoryInfo(file.FullName);
						if (testDir.Exists)
						{
							count += this.NotesInDirectory(new DirectoryInfo(file.FullName));
						}
						else
						{
							count++;
						}
					}
				}
			}
			
			return count;
		}
		
		public bool UseNotes
		{
			get
			{
				return useNotes;
			}
		}
		
		private void SetupUseNotes()
		{
			if (this.Exists())
			{
				FileInfo sysInfo = new FileInfo(this.FullPath + "/iPod_Control/Device/SysInfo");
				if (sysInfo.Exists)
				{
					StreamReader file = new StreamReader(sysInfo.FullName);
					String line;
					while ((line = file.ReadLine()) != null)
					{
						if (line.StartsWith("buildID:"))
						{
							String[] words =  line.Split(" ".ToCharArray());
							if (words.Length == 3)
							{
								String v = words[2].Replace("(", "").Replace(")", "").Substring(0, 1);
								double vers = Convert.ToDouble(v);
								if (vers >= 2)
								{
									useNotes = true;
									return;
								}
							}
						}
					}
				}
			}
			
			useNotes = false;
		}
	}
}