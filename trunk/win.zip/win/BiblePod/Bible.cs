using System;
using System.Xml;
using System.Collections;
using System.Reflection;
using System.IO;

namespace BiblePod
{
	public class Bible
	{
		private XmlDocument doc = null;
		private ArrayList books = null;

		public Bible()
		{
			try
			{
				Assembly assembly = Assembly.GetAssembly(this.GetType());
				Stream stream = assembly.GetManifestResourceStream("BiblePod.KJV_apok.xml");
				doc = new XmlDocument();
				doc.Load(stream);

				books = new ArrayList();
				XmlElement xmlBible = doc.DocumentElement; // XMLBIBLE
				foreach (XmlNode bookNode in xmlBible.ChildNodes)
				{
					if (bookNode.Name == "BIBLEBOOK" &&
						Convert.ToInt32(((bookNode.Attributes["bnumber"]).InnerText)) <= 66)
					{
						books.Add(new BibleBook(bookNode.Attributes["bname"].InnerText, bookNode));
					}
				}
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}

		public ArrayList Books
		{
			get { return books; }
		}

		public BibleBook BookNamed(String name)
		{
			foreach (BibleBook book in books)
				if (book.Name == name)
					return book;
			return null;
		}
	}
}
