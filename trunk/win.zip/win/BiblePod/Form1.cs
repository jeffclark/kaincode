using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;
using System.Data;
using System.Text;
using System.IO;

namespace BiblePod
{
	public class Form1 : System.Windows.Forms.Form
	{
		private Bible bible;

		private System.Windows.Forms.TextBox previewTextBox;
		private System.Windows.Forms.ComboBox bookComboBox;
		private System.Windows.Forms.ComboBox chapterComboBox;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.Label infoLabel;
		private System.Windows.Forms.Button copyButton;
		private System.Windows.Forms.Button clearButton;
		private System.Windows.Forms.ListView ipodListView;
		private System.Windows.Forms.Label bookLabel;
		private System.Windows.Forms.Label chapterLabel;
		private Skybound.VisualStyles.VisualStyleProvider visualStyleProvider1;
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();

			Thread loadThread = new Thread(new System.Threading.ThreadStart(LoadXML));
			loadThread.Start();
		}

		public void LoadXML()
		{
			bible = new Bible();
			Invoke (new MethodInvoker(UpdateUI));
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.bookLabel = new System.Windows.Forms.Label();
			this.bookComboBox = new System.Windows.Forms.ComboBox();
			this.chapterComboBox = new System.Windows.Forms.ComboBox();
			this.chapterLabel = new System.Windows.Forms.Label();
			this.previewTextBox = new System.Windows.Forms.TextBox();
			this.ipodListView = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.infoLabel = new System.Windows.Forms.Label();
			this.copyButton = new System.Windows.Forms.Button();
			this.clearButton = new System.Windows.Forms.Button();
			this.visualStyleProvider1 = new Skybound.VisualStyles.VisualStyleProvider();
			this.SuspendLayout();
			// 
			// bookLabel
			// 
			this.bookLabel.Location = new System.Drawing.Point(16, 18);
			this.bookLabel.Name = "bookLabel";
			this.bookLabel.Size = new System.Drawing.Size(40, 16);
			this.bookLabel.TabIndex = 0;
			this.bookLabel.Text = "Book:";
			this.visualStyleProvider1.SetVisualStyleSupport(this.bookLabel, true);
			// 
			// bookComboBox
			// 
			this.bookComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.bookComboBox.Location = new System.Drawing.Point(56, 16);
			this.bookComboBox.MaxDropDownItems = 40;
			this.bookComboBox.Name = "bookComboBox";
			this.bookComboBox.Size = new System.Drawing.Size(121, 21);
			this.bookComboBox.TabIndex = 1;
			// 
			// chapterComboBox
			// 
			this.chapterComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.chapterComboBox.Location = new System.Drawing.Point(256, 16);
			this.chapterComboBox.MaxDropDownItems = 30;
			this.chapterComboBox.Name = "chapterComboBox";
			this.chapterComboBox.Size = new System.Drawing.Size(64, 21);
			this.chapterComboBox.TabIndex = 3;
			// 
			// chapterLabel
			// 
			this.chapterLabel.Location = new System.Drawing.Point(208, 18);
			this.chapterLabel.Name = "chapterLabel";
			this.chapterLabel.Size = new System.Drawing.Size(48, 16);
			this.chapterLabel.TabIndex = 2;
			this.chapterLabel.Text = "Chapter:";
			this.visualStyleProvider1.SetVisualStyleSupport(this.chapterLabel, true);
			// 
			// previewTextBox
			// 
			this.previewTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.previewTextBox.Location = new System.Drawing.Point(16, 56);
			this.previewTextBox.Multiline = true;
			this.previewTextBox.Name = "previewTextBox";
			this.previewTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.previewTextBox.Size = new System.Drawing.Size(360, 280);
			this.previewTextBox.TabIndex = 4;
			this.previewTextBox.Text = "";
			this.visualStyleProvider1.SetVisualStyleSupport(this.previewTextBox, true);
			// 
			// ipodListView
			// 
			this.ipodListView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.ipodListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						   this.columnHeader1});
			this.ipodListView.Location = new System.Drawing.Point(392, 56);
			this.ipodListView.Name = "ipodListView";
			this.ipodListView.Size = new System.Drawing.Size(152, 280);
			this.ipodListView.TabIndex = 5;
			this.ipodListView.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Saved on iPod";
			this.columnHeader1.Width = 148;
			// 
			// infoLabel
			// 
			this.infoLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.infoLabel.Location = new System.Drawing.Point(16, 355);
			this.infoLabel.Name = "infoLabel";
			this.infoLabel.Size = new System.Drawing.Size(160, 16);
			this.infoLabel.TabIndex = 6;
			this.infoLabel.Text = "0 characters; 0 note(s)";
			this.visualStyleProvider1.SetVisualStyleSupport(this.infoLabel, true);
			// 
			// copyButton
			// 
			this.copyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.copyButton.Location = new System.Drawing.Point(248, 352);
			this.copyButton.Name = "copyButton";
			this.copyButton.Size = new System.Drawing.Size(128, 23);
			this.copyButton.TabIndex = 7;
			this.copyButton.Text = "Copy Selection to iPod";
			this.visualStyleProvider1.SetVisualStyleSupport(this.copyButton, true);
			this.copyButton.Click += new System.EventHandler(this.copyButton_Click);
			// 
			// clearButton
			// 
			this.clearButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.clearButton.Location = new System.Drawing.Point(469, 352);
			this.clearButton.Name = "clearButton";
			this.clearButton.TabIndex = 8;
			this.clearButton.Text = "Clear All";
			this.visualStyleProvider1.SetVisualStyleSupport(this.clearButton, true);
			this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(560, 390);
			this.Controls.Add(this.clearButton);
			this.Controls.Add(this.copyButton);
			this.Controls.Add(this.infoLabel);
			this.Controls.Add(this.ipodListView);
			this.Controls.Add(this.previewTextBox);
			this.Controls.Add(this.chapterComboBox);
			this.Controls.Add(this.chapterLabel);
			this.Controls.Add(this.bookComboBox);
			this.Controls.Add(this.bookLabel);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form1";
			this.Text = "BiblePod";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.DoEvents();
			Application.Run(new Form1());
		}

		public void UpdateUI()
		{
			foreach (BibleBook book in bible.Books)
			{
				bookComboBox.Items.Add(book.Name);
			}
			bookComboBox.SelectedIndex = 0;
			chapterComboBox.SelectedIndex = 0;
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			try
			{
				bookComboBox.SelectedIndexChanged += new EventHandler(bookComboBox_SelectedIndexChanged);
				chapterComboBox.SelectedIndexChanged += new EventHandler(chapterComboBox_SelectedIndexChanged);

				bookComboBox.Items.Clear();
				chapterComboBox.Items.Clear();
				bookComboBox.SelectedIndex = 0;
				chapterComboBox.SelectedIndex = 0;

				UpdateiPodList();
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}

		private void bookComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				chapterComboBox.Items.Clear();
				BibleBook book = bible.BookNamed(bookComboBox.Text);
				chapterComboBox.Items.Add("All");
				for (int i=0; i<book.ChapterCount; i++)
				{
					chapterComboBox.Items.Add((i+1).ToString());
				}
				chapterComboBox.SelectedIndex = 0;
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}

		private void chapterComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			PreviewSelection();
		}

		private void PreviewSelection()
		{
			try
			{
				BibleBook book = bible.BookNamed(bookComboBox.Text);
				String chapterStr = chapterComboBox.Text;
				if (chapterStr == "All")
				{
					previewTextBox.Text = "No preview available.";
					infoLabel.Text = "0 characters; 0 note(s)";
				}
				else
				{
					previewTextBox.Text = FormatVerses(book.Chapter(Convert.ToInt32(chapterStr)-1));
					int l = previewTextBox.Text.Replace("\r\n", "\r").Length;
					infoLabel.Text = String.Format("{0} characters; {1} note(s)", l, l/4096+1);
				}
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}

		private String FormatVerses(ArrayList verses)
		{
			StringBuilder str = new StringBuilder();
			for (int i=0; i<verses.Count; i++)
				str.AppendFormat("[{0}] {1}\r\n\r\n", i+1, verses[i].ToString());
			return str.ToString().Trim();
		}

		private void copyButton_Click(object sender, System.EventArgs e)
		{
			try
			{
				iPod iPod = new iPod();
				if (!iPod.Exists())
				{
					MessageBox.Show("No iPod was found connected to this computer.");
					return;
				}

				BibleBook book = bible.BookNamed(bookComboBox.Text);
				String chapterStr = chapterComboBox.Text;

				if (!Directory.Exists(iPod.NotesFolder))
					Directory.CreateDirectory(iPod.NotesFolder);
				if (!Directory.Exists(iPod.BiblePodFolder))
					Directory.CreateDirectory(iPod.BiblePodFolder);
				if (!Directory.Exists(iPod.BiblePodFilesFolder))
					Directory.CreateDirectory(iPod.BiblePodFilesFolder);

				if (chapterStr == "All")
				{
					for (int i=0; i<book.ChapterCount; i++)
					{
						ChapterToiPod(i, book, iPod);
					}
				}
				else
				{
					int chapter = Convert.ToInt32(chapterStr);
					ChapterToiPod(chapter-1, book, iPod);
				}

				UpdateiPodList();
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception);
			}
		}
		
		private void ChapterToiPod(int chapter, BibleBook book, iPod ipod)
		{
			String bookName = book.Name;
			ArrayList verses = book.Chapter(chapter);
			
			StringBuilder output = new StringBuilder();
			StringBuilder outputWithTitle = new StringBuilder();
			StringBuilder prevOutputWithTitle = new StringBuilder();
			String linxPath = String.Format(@"{0}\{1}.linx", ipod.BiblePodFolder, bookName);
			StringBuilder linx = new StringBuilder();
			String linxTitle = String.Format("<title>{0}</title>", bookName);

			if (File.Exists(linxPath))
			{
				StreamReader str = new StreamReader(linxPath);
				String oldLinx = str.ReadToEnd();
				str.Close();
				linx.Append(oldLinx);
			}
			if (!linx.ToString().StartsWith(linxTitle)) linx.Append(linxTitle);

			int startv = 1;
			for (int i=0; i<verses.Count+1; i++)
			{
				String proposed, name, filename, verse = "";

				name = String.Format("{0}:{1}-{2}", chapter+1, startv, i);
				filename = String.Format("{0}!{1}{2}", bookName, chapter+1, i);

				if (i+1==startv)
					output.Remove(0, output.Length);

				if (i < verses.Count)
				{
					verse = String.Format("[{0}] {1}\r\r", i+1, verses[i]);
					proposed = String.Format("{0}{1}", output, verse);
				}
				else
				{
					proposed = output.ToString();
				}

				outputWithTitle.Remove(0, outputWithTitle.Length);
				prevOutputWithTitle.Remove(0, prevOutputWithTitle.Length);
				outputWithTitle.Append(String.Format("<title>{0}</title>{1}", name, proposed));
				prevOutputWithTitle.Append(String.Format("<title>{0}</title>{1}", name, output.ToString()));

				if (outputWithTitle.Length > 4096 || i==verses.Count)
				{
					String path = String.Format(@"{0}\files\{1}", ipod.BiblePodFolder, filename);

					StreamWriter w1 = new StreamWriter(path, false);
					w1.Write(prevOutputWithTitle.ToString().Trim());
					w1.Close();

					linx.AppendFormat("<a href=\"files\\{0}\">{1}</a>\r", filename, name);

					output.Remove(0, output.Length);
					output.Append(verse);//Format("{0}\r\r", verse);
					startv = i+1;
				}
				else
				{
					output.Remove(0, output.Length);
					output.Append(proposed);
				}
			}

			StreamWriter w2 = new StreamWriter(linxPath, false);
			w2.Write(linx);
			w2.Close();
		}

		private void UpdateiPodList()
		{
			try
			{
				iPod ipod = new iPod();
				if (!ipod.Exists()) return;
			
				ipodListView.Items.Clear();
				DirectoryInfo info = new DirectoryInfo(ipod.BiblePodFilesFolder);
				foreach (FileInfo file in info.GetFiles())
				{
					string[] split = file.Name.Split("!".ToCharArray());
					StreamReader sr = new StreamReader(file.FullName);
					String text = sr.ReadToEnd();
					sr.Close();

					int s = text.IndexOf("</title>");
					String title = text.Substring(0, s).Replace("<title>", "");
					ipodListView.Items.Add(String.Format("{0} {1}", split[0], title));
				}
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}

		private void clearButton_Click(object sender, System.EventArgs e)
		{
			try
			{
				iPod iPod = new iPod();
				if (!iPod.Exists()) return;

				Directory.Delete(iPod.BiblePodFolder, true);
				UpdateiPodList();
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}
	}
}
