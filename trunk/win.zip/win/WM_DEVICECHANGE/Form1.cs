using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace WM_DEVICECHANGE
{
	public class Form1 : System.Windows.Forms.Form
	{
		// http://www.dotnet247.com/247reference/msgs/43/217435.aspx

		public delegate int MyWindowProcDelegate(int hwnd, int Msg, int wParam, int lParam);
		public event MyWindowProcDelegate Delly;

		[DllImport("user32.dll", EntryPoint = "CallWindowProcA")]
		public static extern int CallWindowProc(int lpPrevWndFunc, int hwnd, int Msg, int wParam, int lParam);
		
		[DllImport("user32.dll", EntryPoint = "GetWindowLongA")]
		public static extern int GetWindowLong(int hwnd, int nIndex);

		[DllImport("user32.dll", EntryPoint = "SetWindowLongA")]
		public static extern int SetWindowLong(int hwnd, int nIndex, MyWindowProcDelegate dwNewLong);

		const int GWL_WNDPROC = -4;
		const int WM_DEVICECHANGE = 0x219;

		const int UNSAFE_REMOVE = 0x1C;
		const int DBT_DEVICEARRIVAL = 0x8000; // system detected a new device
		const int DBT_DEVTYP_VOLUME = 0x00000002; // logical volume
		const int DBT_DEVICEREMOVECOMPLETE = 0x8004;

		int glngPrevWndProc;

		[StructLayout(LayoutKind.Sequential)]
			public struct DEV_BROADCAST_VOLUME
		{
			public int dbcv_size;
			public int dbcv_devicetype;
			public int dbcv_reserved;
			public int dbcv_unitmask;
		}


		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();

			Delly += new MyWindowProcDelegate(MyWindowProc);
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			glngPrevWndProc = GetWindowLong(Handle.ToInt32(), GWL_WNDPROC);
			SetWindowLong(Handle.ToInt32(), GWL_WNDPROC, Delly);
		}

		public int MyWindowProc(int hwnd, int Msg, int wParam, int lParam)
		{
			if (Msg == WM_DEVICECHANGE)
			{
				switch (wParam)
				{
					case DBT_DEVICEARRIVAL:
						MessageBox.Show("Device arrival!");
						GetDriveLetter(lParam);
						break;

					case DBT_DEVICEREMOVECOMPLETE:
						MessageBox.Show("Device removal!");
						GetDriveLetter(lParam);
						break;
				}

				return 0;
			}

			return CallWindowProc(glngPrevWndProc, hwnd, Msg, wParam, lParam);
		}

		protected void GetDriveLetter(int LParam)
		{
			char d;
			int i;
			int devType = Marshal.ReadInt32(LParam,4);
			
			DEV_BROADCAST_VOLUME vol = (DEV_BROADCAST_VOLUME)
					Marshal.PtrToStructure(new IntPtr(LParam), typeof(DEV_BROADCAST_VOLUME));

			int unitmask = vol.dbcv_unitmask;

			for (i=0; i<26; ++i)
			{
				if ((unitmask & 0x1) != 0)
					break;
				unitmask = unitmask >> 1;
			}
			d =  (char)(i + (int)'A');

			MessageBox.Show("ascii: " + new string(d, 1));
		}
	}
}
