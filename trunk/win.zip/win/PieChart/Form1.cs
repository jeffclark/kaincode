using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PieChart
{
	public class Form1 : System.Windows.Forms.Form
	{
		private int rotation = 0, size = 100;

		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TrackBar trackBar1;
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();

			this.Paint += new PaintEventHandler(Form1_Paint);
			this.MouseWheel += new MouseEventHandler(Form1_MouseWheel);
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.trackBar1 = new System.Windows.Forms.TrackBar();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(16, 224);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(176, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "20, 20, 20";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(200, 224);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(48, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "Go";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// trackBar1
			// 
			this.trackBar1.Location = new System.Drawing.Point(24, 168);
			this.trackBar1.Maximum = 360;
			this.trackBar1.Name = "trackBar1";
			this.trackBar1.Size = new System.Drawing.Size(120, 45);
			this.trackBar1.TabIndex = 2;
			this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
			this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.Add(this.trackBar1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.textBox1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void Form1_Paint(object sender, PaintEventArgs e)
		{
			try
			{
				ArrayList colors = new ArrayList(new object[]{Color.Red, Color.Green, Color.Blue, Color.Magenta, Color.Cyan, Color.Orange, Color.Yellow, Color.Brown, Color.Gray});
				Graphics g = e.Graphics;
				Pen pen = new Pen(Color.Red, 2);
				Rectangle rect = new Rectangle((this.DisplayRectangle.Width-size)/2, 0, size, size);
				string[] splits = textBox1.Text.Split(",".ToCharArray());
				int startAngle = rotation, angle;
				int total = 0, c=0;
				
				for (int i=0; i<splits.Length; i++)
					total += Convert.ToInt32(splits[i]);
			
				for (int i=0; i<splits.Length; i++)
				{
					pen.Color = (Color)colors[(c == colors.Count ? c=0 : c++)];
					double v = Convert.ToDouble(splits[i]);
					angle = Convert.ToInt32(360 * (v/total));
					
					g.FillPie(pen.Brush, rect, startAngle, angle);

					startAngle += angle;
				}
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}
		private void button1_Click(object sender, System.EventArgs e)
		{
			this.Refresh();
		}

		private void trackBar1_Scroll(object sender, System.EventArgs e)
		{
			rotation = trackBar1.Value;
			this.Refresh();
		}

		private void Form1_MouseWheel(object sender, MouseEventArgs e)
		{
			/*if (e.Delta > 0)
				size += 10;
			else
				if (size > 10)
					size -= 10;
			this.Refresh();*/
		}
	}
}
