using System;
using System.Collections;
using System.IO;
using System.Text;

// http://www.ipodlinux.org/iTunesDB

namespace PodMusic
{
	public class iPodParser
	{
		private iPod _iPod;
		private ArrayList _tracks;
		private Track _currentTrack;

		enum iPodParserMhodType
		{
			MhodTypeTitle = 1,
			MhodTypeLocation = 2,
			MhodTypeAlbum = 3,
			MhodTypeArtist = 4,
			MhodTypeGenre = 5,
			MhodTypeFileType = 6,
			MhodTypeEQSetting = 7,
			MhodTypeComment = 8,
			MhodTypePodcastCategory = 9,
			MhodTypeComposer = 12,
			MhodTypeGrouping = 13,
			MhodTypePodcastDescription = 14,
			MhodTypePodcastRSSURL = 15,
			MhodTypePodcastEnclosureURL = 16,
			MhodTypeSmartPlaylistData = 50,
			MhodTypeSmartPlaylistRules = 51,
			MhodTypeLibraryPlaylistIndex = 52,
			MhodTypePlaylistSortIndicator = 100
		}

		public iPodParser(iPod pod)
		{
			if (pod.Exists)
			{
				_iPod = pod;
				LoadTracks();
			}
		}

		private void LoadTracks()
		{
			try
			{
				string iTunesDBPath = _iPod.Path + @"iPod_Control\iTunes\iTunesDB";
				FileInfo fi = new FileInfo(iTunesDBPath);
				if (fi.Exists)
				{
					// read data into memory
					Stream stream = new StreamReader(iTunesDBPath).BaseStream;
					byte[] bytes = new byte[stream.Length];
					stream.Read(bytes, 0, (int)stream.Length);

					Console.WriteLine("length: {0}", bytes.Length);

					_tracks = new ArrayList();
					int position = 0;
					ProcessiTunesDB(ref bytes, ref position);
				}
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}

		private void ProcessiTunesDB(ref byte[] bytes, ref int position)
		{
			string headerID = ReadString(ref bytes, position, 4);
			ulong headerLength = ReadInt(ref bytes, position+4, 4);
			
			if (headerID == "mhbd")
			{
				//uint totalLength = ReadInt(ref bytes, position+8, 4);
				//Console.WriteLine("total length: {0}", totalLength);
				//ulong dbVersion = ReadInt(ref bytes, position+16, 4);
				//Console.WriteLine("dbVersion: {0}", dbVersion);
			}
			else if (headerID == "mhsd")
			{
				uint mhsdTotalLength = ReadInt(ref bytes, position+8, 4);
				uint mhsdType = ReadInt(ref bytes, position+12, 4);
				if (mhsdType == 3) // Podcasts
				{
					position += (int)(mhsdTotalLength - headerLength);
				}
			}
			else if (headerID == "mhlt") // track list
			{
				uint numberOfSongs = ReadInt(ref bytes, position+8, 4);
				int startp = position + (int)headerLength;
				Console.WriteLine("startp: {0}", startp);
				for (int i=0; i<numberOfSongs; i++)
					startp += ProcessMHIT(ref bytes, startp);
			}

			position += (int)headerLength;
			if (position >= bytes.Length)
				return;

			ProcessiTunesDB(ref bytes, ref position);
		}

		private int ProcessMHIT(ref byte[] bytes, int position)
		{
			uint headerLength = ReadInt(ref bytes, position+4, 4);

			int localPos = position + 4;
			uint totalLength = ReadInt(ref bytes, localPos += 4, 4);
			uint numberOfStrings = ReadInt(ref bytes, localPos += 4, 4);

			_currentTrack = new Track();

			int startp = position + (int)headerLength;
            for (int i=0; i<numberOfStrings; i++)
				startp += ProcessMHODOrMHIP(ref bytes, startp);

			_tracks.Add(_currentTrack);
			
			return (int)totalLength;
		}

		private int ProcessMHODOrMHIP(ref byte[] bytes, int position)
		{
			string headerID = ReadString(ref bytes, position, 4);
			uint headerLength = ReadInt(ref bytes, position+4, 4);
			uint totalLength = ReadInt(ref bytes, position+8, 4);

			if (headerID == "mhod")
			{
				iPodParserMhodType type = (iPodParserMhodType)ReadInt(ref bytes, position+12, 4);
				uint stringLength = ReadInt(ref bytes, position+28, 4);

				string mhodString = null;

				if (type != iPodParserMhodType.MhodTypePodcastEnclosureURL && type != iPodParserMhodType.MhodTypePodcastRSSURL)
				{
					// read 2 bytes per char
					char[] chars = new char[stringLength/2];
					int k = 0;
					for (int i=0; i<stringLength; i+=2)
					{
						chars[k] = (char)ReadInt(ref bytes, position + ((int)totalLength - (int)stringLength) + i, 2);
						k++;
					}

					//mhodString = System.Text.Encoding.UTF8.GetString(chars, 0, (int)stringLength);
					mhodString = new string(chars);
				}

				switch (type)
				{
					case iPodParserMhodType.MhodTypeTitle:
						_currentTrack.title = mhodString;
						break;
					case iPodParserMhodType.MhodTypeLocation:
						string path = mhodString.Replace(":", @"\");
						path = path.Remove(0, 1); // removes the extra \ at the front
						path = _iPod.Path + path;
						_currentTrack.location = path;
						break;
					case iPodParserMhodType.MhodTypeArtist:
						_currentTrack.artist = mhodString;
						break;
					case iPodParserMhodType.MhodTypeAlbum:
						_currentTrack.album = mhodString;
						break;
					case iPodParserMhodType.MhodTypeGenre:
						_currentTrack.genre = mhodString;
						break;
					case iPodParserMhodType.MhodTypeComment:
						_currentTrack.comment = mhodString;
						break;
					case iPodParserMhodType.MhodTypePodcastRSSURL:
						_currentTrack.podcastRSSURL = mhodString;
						_currentTrack.isPodcast = true;
						break;
					case iPodParserMhodType.MhodTypePodcastEnclosureURL:
						_currentTrack.podcastEnclosureURL = mhodString;
						_currentTrack.isPodcast = true;
						break;
					case iPodParserMhodType.MhodTypePodcastCategory:
						_currentTrack.podcastCategory = mhodString;
						_currentTrack.isPodcast = true;
						break;
					case iPodParserMhodType.MhodTypePodcastDescription:
						_currentTrack.podcastDescription = mhodString;
						_currentTrack.isPodcast = true;
						break;
				}
			}

			return (int)totalLength;
		}

		private string ReadString(ref byte[] bytes, int position, int length)
		{
			byte[] buf = new byte[length];
			for (int i=0; i<length; i++)
				buf[i] = bytes[position + i];
			String output = System.Text.Encoding.UTF8.GetString(buf, 0, length);
			return output;
		}

		private uint ReadInt(ref byte[] bytes, int position, int length) // length must be 4 or 2 only
		{
			byte[] buf = new byte[length];
			for (int i=0; i<length; i++)
				buf[i] = bytes[position + i];
			
			uint output = 0;
			if (length == 4)
				output = ((uint)buf[3] << 24) | ((uint)buf[2] << 16) | ((uint)buf[1] << 8) | ((uint)buf[0]);
			else if (length == 2)
				output = ((uint)buf[1] << 8) | ((uint)buf[0]);

			return output;
		}

		public ArrayList Tracks
		{
			get { return _tracks; }
		}
	}
}
