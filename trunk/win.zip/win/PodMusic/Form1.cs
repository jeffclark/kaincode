using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;

namespace PodMusic
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private Skybound.VisualStyles.VisualStyleProvider visualStyleProvider1;
		private System.Windows.Forms.ListView listView1;

		private TrackPlayer _trackPlayer;
		private SourceListItem _selectedSource;
		private ArrayList _tracks, _viewedTracks;
		private ArrayList _genres;
		private ArrayList _artists;
		private ArrayList _albums;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox genresCombo;
		private System.Windows.Forms.ComboBox artistsCombo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox albumsCombo;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox searchBox;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ListView sourcesListView;

		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.visualStyleProvider1 = new Skybound.VisualStyles.VisualStyleProvider();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.searchBox = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.listView1 = new System.Windows.Forms.ListView();
			this.genresCombo = new System.Windows.Forms.ComboBox();
			this.artistsCombo = new System.Windows.Forms.ComboBox();
			this.albumsCombo = new System.Windows.Forms.ComboBox();
			this.sourcesListView = new System.Windows.Forms.ListView();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(168, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(104, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Genres";
			this.visualStyleProvider1.SetVisualStyleSupport(this.label1, true);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(368, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(104, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "Artists";
			this.visualStyleProvider1.SetVisualStyleSupport(this.label2, true);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(568, 16);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(104, 16);
			this.label3.TabIndex = 6;
			this.label3.Text = "Albums";
			this.visualStyleProvider1.SetVisualStyleSupport(this.label3, true);
			// 
			// searchBox
			// 
			this.searchBox.Location = new System.Drawing.Point(624, 424);
			this.searchBox.Name = "searchBox";
			this.searchBox.Size = new System.Drawing.Size(136, 20);
			this.searchBox.TabIndex = 9;
			this.searchBox.Text = "";
			this.visualStyleProvider1.SetVisualStyleSupport(this.searchBox, true);
			this.searchBox.TextChanged += new System.EventHandler(this.searchBox_TextChanged);
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(624, 408);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(104, 16);
			this.label4.TabIndex = 10;
			this.label4.Text = "Search:";
			this.visualStyleProvider1.SetVisualStyleSupport(this.label4, true);
			// 
			// listView1
			// 
			this.listView1.FullRowSelect = true;
			this.listView1.Location = new System.Drawing.Point(168, 64);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(592, 328);
			this.listView1.TabIndex = 1;
			this.listView1.View = System.Windows.Forms.View.Details;
			this.listView1.DoubleClick += new System.EventHandler(this.listView1_DoubleClick);
			// 
			// genresCombo
			// 
			this.genresCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.genresCombo.Location = new System.Drawing.Point(168, 32);
			this.genresCombo.Name = "genresCombo";
			this.genresCombo.Size = new System.Drawing.Size(192, 21);
			this.genresCombo.TabIndex = 3;
			this.genresCombo.SelectedIndexChanged += new System.EventHandler(this.genresCombo_SelectedIndexChanged);
			// 
			// artistsCombo
			// 
			this.artistsCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.artistsCombo.Location = new System.Drawing.Point(368, 32);
			this.artistsCombo.Name = "artistsCombo";
			this.artistsCombo.Size = new System.Drawing.Size(192, 21);
			this.artistsCombo.TabIndex = 5;
			this.artistsCombo.SelectedIndexChanged += new System.EventHandler(this.artistsCombo_SelectedIndexChanged);
			// 
			// albumsCombo
			// 
			this.albumsCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.albumsCombo.Location = new System.Drawing.Point(568, 32);
			this.albumsCombo.Name = "albumsCombo";
			this.albumsCombo.Size = new System.Drawing.Size(192, 21);
			this.albumsCombo.TabIndex = 7;
			this.albumsCombo.SelectedIndexChanged += new System.EventHandler(this.albumsCombo_SelectedIndexChanged);
			// 
			// sourcesListView
			// 
			this.sourcesListView.FullRowSelect = true;
			this.sourcesListView.Location = new System.Drawing.Point(16, 16);
			this.sourcesListView.Name = "sourcesListView";
			this.sourcesListView.Size = new System.Drawing.Size(144, 376);
			this.sourcesListView.TabIndex = 13;
			this.sourcesListView.View = System.Windows.Forms.View.Details;
			this.sourcesListView.SelectedIndexChanged += new System.EventHandler(this.sourcesListView_SelectedIndexChanged);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(784, 462);
			this.Controls.Add(this.sourcesListView);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.searchBox);
			this.Controls.Add(this.albumsCombo);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.artistsCombo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.genresCombo);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.listView1);
			this.Name = "Form1";
			this.Text = "Music";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion
		[STAThread]
		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.DoEvents();
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			sourcesListView.Columns.Add("Source", 150, System.Windows.Forms.HorizontalAlignment.Left);
			listView1.Columns.Add("", 20, System.Windows.Forms.HorizontalAlignment.Left);
			listView1.Columns.Add("Song Name", 200, System.Windows.Forms.HorizontalAlignment.Left);
			listView1.Columns.Add("Artist", 200, System.Windows.Forms.HorizontalAlignment.Left);
			listView1.Columns.Add("Album", 200, System.Windows.Forms.HorizontalAlignment.Left);

			UpdateiPods();		
		}

		private void UpdateiPods()
		{
			sourcesListView.Items.Clear();

			SourceListItem itunesSource = new SourceListItem(SourceListItem.SourceType.iTunesLibrary);
			itunesSource.Name = "iTunes";
			itunesSource.Tracks = (new iTunesSource()).Tracks;
			sourcesListView.Items.Add(itunesSource);

			ArrayList iPods = iPod.ConnectediPods();
			foreach (iPod pod in iPods)
			{
				SourceListItem sourceItem = new SourceListItem(SourceListItem.SourceType.iPodLibrary);
				sourceItem.SourceObject = (Object)pod;
				sourceItem.Name = pod.Name;
				sourceItem.Tracks = pod.Tracks;
				sourcesListView.Items.Add(sourceItem);
			}
		}

		private void UpdateGenres()
		{
			if (_genres == null)
				_genres = new ArrayList();
			_genres.Clear();
			genresCombo.Items.Clear();

			if (_tracks != null)
			{
				foreach (Track t in _tracks)
				{
					if (t.genre != null && t.genre != "" && !_genres.Contains(t.genre))
						_genres.Add(t.genre);
				}
				_genres.Sort();

				genresCombo.Items.Add(String.Format("All ({0} Genres)", _genres.Count));
				foreach (string g in _genres)
					genresCombo.Items.Add(g);
				genresCombo.SelectedIndex = 0;
			}

			UpdateArtists();
		}

		private void UpdateArtists()
		{
			if (_artists == null)
				_artists = new ArrayList();
			_artists.Clear();
			artistsCombo.Items.Clear();

			if (_tracks != null)
			{
				string selectedGenre = genresCombo.SelectedItem.ToString();
				foreach (Track t in _tracks)
				{
					if (t.artist != null && t.artist != "" && !_artists.Contains(t.artist))
					{
						if (selectedGenre.StartsWith("All") || t.genre == selectedGenre)
							_artists.Add(t.artist);
					}
				}
				_artists.Sort();

				artistsCombo.Items.Add(String.Format("All ({0} Artists)", _artists.Count));
				foreach (string a in _artists)
					artistsCombo.Items.Add(a);
				artistsCombo.SelectedIndex = 0;
			}

			UpdateAlbums();
		}

		private void UpdateAlbums()
		{
			if (_albums == null)
				_albums = new ArrayList();
			_albums.Clear();
			albumsCombo.Items.Clear();

			if (_tracks != null)
			{
				string selectedGenre = genresCombo.SelectedItem.ToString();
				string selectedArtist = artistsCombo.SelectedItem.ToString();
				foreach (Track t in _tracks)
				{
					if (t.album != null && t.album != "" && !_albums.Contains(t.album))
					{
						if (selectedGenre.StartsWith("All") || t.genre == selectedGenre)
							if (selectedArtist.StartsWith("All") || t.artist == selectedArtist)
								_albums.Add(t.album);
					}
				}
				_albums.Sort();

				albumsCombo.Items.Add(String.Format("All ({0} Albums)", _albums.Count));
				foreach (string a in _albums)
					albumsCombo.Items.Add(a);
				albumsCombo.SelectedIndex = 0;
			}

			UpdateViewedTracks();
		}

		private void UpdateViewedTracks()
		{
			if (_viewedTracks == null)
				_viewedTracks = new ArrayList();
			_viewedTracks.Clear();
			listView1.Items.Clear();
			
			if (_tracks != null)
			{
				if (searchBox.Text == "")
				{
					string selectedGenre = genresCombo.SelectedItem.ToString();
					string selectedArtist = artistsCombo.SelectedItem.ToString();
					string selectedAlbum = albumsCombo.SelectedItem.ToString();

					foreach (Track t in _tracks)
						if (selectedGenre.StartsWith("All") || t.genre == selectedGenre)
							if (selectedArtist.StartsWith("All") || t.artist == selectedArtist)
								if (selectedAlbum.StartsWith("All") || t.album == selectedAlbum)
									_viewedTracks.Add(t);
				}
				else
				{
					// do live search
					string keywords = searchBox.Text.ToLower();
					foreach (Track t in _tracks)
					{
						if ((t.title != null && t.title.ToLower().IndexOf(keywords) != -1) ||
							(t.artist != null && t.artist.ToLower().IndexOf(keywords) != -1) ||
							(t.album != null && t.album.ToLower().IndexOf(keywords) != -1) ||
							(t.genre != null && t.genre.ToLower().IndexOf(keywords) != -1) ||
							(t.comment != null && t.comment.ToLower().IndexOf(keywords) != -1))
							_viewedTracks.Add(t);
					}
				}

				listView1.BeginUpdate();
				foreach (Track t in _viewedTracks)
				{
					string[] items = {"", t.title, t.artist, t.album};
					ListViewItem item = new ListViewItem(items);
					listView1.Items.Add(item);
				}
				listView1.EndUpdate();
			}
		}

		private void genresCombo_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			UpdateArtists();
		}

		private void artistsCombo_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			UpdateAlbums();
		}

		private void albumsCombo_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			UpdateViewedTracks();
		}

		private void listView1_DoubleClick(object sender, EventArgs e)
		{
			Track t = (Track)_viewedTracks[listView1.SelectedIndices[0]];
			if (_trackPlayer == null)
				_trackPlayer = new TrackPlayer();
			_trackPlayer.SetTrack(t);
			_trackPlayer.Play();
		}

		private void searchBox_TextChanged(object sender, System.EventArgs e)
		{
			UpdateViewedTracks();
		}

		private void sourcesListView_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (sourcesListView.SelectedItems.Count > 0)
			{
				_selectedSource = (SourceListItem)sourcesListView.SelectedItems[0];
				_tracks = _selectedSource.Tracks;
			}
			else
			{
				_selectedSource = null;
				_tracks = null;
			}

			UpdateGenres();
		}
	}
}
