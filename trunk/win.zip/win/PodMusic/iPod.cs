using System;
using System.Collections;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace PodMusic
{
	public class iPod
	{
		private string _path;
		private string _name;
		private bool _exists;
		private iPodParser _ipodParser;

		public static ArrayList ConnectediPods()
		{
			ArrayList pods = new ArrayList();
			string[] drives = Environment.GetLogicalDrives();
			foreach (string drive in drives)
			{
				if (drive.StartsWith("A") == true)
					continue;

				iPod pod = new iPod(drive);
				if (pod.Exists)
					pods.Add(pod);
			}

			return pods;
		}

		public iPod(string podPath)
		{
			string iPodControlPath = podPath + @"iPod_Control\";
			DirectoryInfo di = new DirectoryInfo(iPodControlPath);
			if (di.Exists)
			{
				_path = podPath;
				_exists = true;
			}
			else
			{
				_exists = false;
			}
	}

		public string Path
		{
			get { return _path; }
		}

		public string Name
		{
			get
			{
				if (_name == null)
				{
					_name = GetDriveName(_path);
				}

				return _name;
			}
		}

		[DllImport("kernel32.dll")]
		public static extern long GetDriveType(string driveLetter);
		[DllImport("kernel32.dll")]
		public static extern long GetVolumeInformation(string strPathName,
			StringBuilder strVolumeNameBuffer,
			long lngVolumeNameSize,
			long lngVolumeSerialNumber,
			long lngMaximumComponentLength,
			long lngFileSystemFlags,
			StringBuilder strFileSystemNameBuffer,
			long lngFileSystemNameSize);

		public string GetDriveName(string drive)
		{
			//receives volume name of drive
			StringBuilder volname = new StringBuilder(256);
			//receives serial number of drive,not in case of network drive(win95/98)
			long sn= new long();
			long maxcomplen = new long();//receives maximum component length
			long sysflags = new long();//receives file system flags
			StringBuilder sysname = new StringBuilder(256);//receives the file system name
			long retval= new long();//return value

			retval = GetVolumeInformation(drive, volname, 256, sn, maxcomplen, 
				sysflags, sysname,256);
            
			if (retval!=0)
				return volname.ToString();
			return "";
		}

		public bool Exists
		{
			get { return _exists; }
		}

		public ArrayList Tracks
		{
			get
			{
				if (_ipodParser == null)
					_ipodParser = new iPodParser(this);
				return _ipodParser.Tracks;
			}
		}
	}
}
