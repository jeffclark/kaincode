using System;
using System.Windows.Forms;
using System.Collections;

namespace PodMusic
{
	public class SourceListItem : ListViewItem
	{
		public enum SourceType
		{
			iPodLibrary, iPodPlaylist, iPodSmartPlaylist, iPodPodcasts,
			iTunesLibrary, iTunesPlaylist, iTunesSmartPlaylist, iTunesPodcast
		}

		public SourceType Type;
		public Object SourceObject;
		private string name;
		public ArrayList Tracks;

		public SourceListItem(SourceType aType) : base()
		{
			Type = aType;
			SourceObject = null;
		}

		public string Name
		{
			get
			{
				return name;
			}

			set
			{
				name = value;
				base.Text = name;
			}
		}

		public override string ToString()
		{
			return name;
		}
	}
}
