using System;
using System.Text;
using System.Collections;

namespace PodMusic
{
	public class iTunesSource
	{
		private ArrayList _tracks;

		public iTunesSource()
		{
			try
			{
				string iTunesXMLPath = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic) + @"\iTunes\iTunes Music Library.xml";
				PlistParser plistParser = new PlistParser(iTunesXMLPath);
				Object rootObject = plistParser.RootObject;

				if (rootObject.GetType().ToString() == "System.Collections.Hashtable")
				{
					Hashtable dict = (Hashtable)rootObject;
					Hashtable plistTracks = (Hashtable)dict["Tracks"];
					if (plistTracks != null)
					{
						_tracks = new ArrayList();

						int i=0;
						foreach (string trackID in plistTracks.Keys)
						{
							Hashtable tdict = (Hashtable)plistTracks[trackID];
							Track track = new Track();

							track.title = (string)tdict["Name"];
							track.artist = (string)tdict["Artist"];
							track.album = (string)tdict["Album"];
							track.genre = (string)tdict["Genre"];
						
							Uri url = new Uri((string)tdict["Location"]);
							track.location = url.LocalPath;
							track.location = track.location.Replace(@"\\localhost\", "");

							_tracks.Add(track);
						}
					}
				}
			}
			catch (Exception exception)
			{
				Console.WriteLine(exception.Message);
			}
		}

		public ArrayList Tracks
		{
			get
			{
				Console.WriteLine("HEY");
				return _tracks;
			}
		}
	}
}
