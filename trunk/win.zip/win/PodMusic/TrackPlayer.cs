using System;
using System.Text;
using System.Runtime.InteropServices;

// http://dotnet.org.za/deon/articles/3057.aspx

namespace PodMusic
{
	public class TrackPlayer
	{
		private Track _track;
		private bool _trackOpen;

		public TrackPlayer()
		{
			_trackOpen = false;
		}

		public void SetTrack(Track track)
		{
			if (_trackOpen)
			{
				mciSendString("stop MediaFile", null, 0, IntPtr.Zero);
				mciSendString("close MediaFile", null, 0, IntPtr.Zero);
			}

			_track = track;
			_trackOpen = false;
		}

		[DllImport("winmm.dll")]
		private static extern long mciSendString(string strCommand, StringBuilder strReturn, int iReturnLength, IntPtr hwndCallback);
		
		public void Play()
		{
			if (_trackOpen == false)
			{
				Console.WriteLine(_track.location);
				string sCommand = "open \"" + _track.location + "\" type mpegvideo alias MediaFile";
				mciSendString(sCommand, null, 0, IntPtr.Zero);
				_trackOpen = true;
			}

			mciSendString("play MediaFile", null, 0, IntPtr.Zero);
		}
	}
}
