using System;

namespace PodMusic
{
	public class Track
	{
		public uint UID;
		public bool compilation;
		public uint rating;
		public DateTime dateAdded;
		public uint size;
		public uint length;
		public uint trackNumber;
		public uint totalTracks;
		public uint year;
		public uint bitrate;
		public uint sampleRate;
		public uint volume;
		public uint startTime;
		public uint stopTime;
		public uint playCount;
		public DateTime lastTimePlayed;
		public uint discNumber;
		public uint totalDiscs;
		public DateTime dateModified;
		public uint bookmarkTime;
		public ulong dbid;
		public bool isChecked;
		public uint artworkSize;
		public string title;
		public string location;
		public string album;
		public string artist;
		public string genre;
		public string filetype;
		public string eqsetting;
		public string comment;
		public string composer;
		public string grouping;

		public string podcastEnclosureURL;
		public string podcastRSSURL;
		public string podcastCategory;
		public string podcastDescription;
		public bool isPodcast;

		public string playlistName;

		public Track()
		{
			compilation = false;
			isChecked = false;
			isPodcast = false;
		}

		public override string ToString()
		{
			return String.Format("{0} - {1}", this.title, this.artist);
		}

	}
}
