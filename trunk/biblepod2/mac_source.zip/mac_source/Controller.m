#import "Controller.h"
#import "BPBible.h"
#import "BPBook.h"
#import "BPChapter.h"
#import "BPVerse.h"

@interface Controller (priv)
- (void)loadBibleForLanguage:(BPLanguage)language;
- (void)setupUI;

- (void)chapterToiPod:(BPChapter *)chapter book:(BPBook *)biblebook;
- (NSString *)iPod;
- (int)notesOniPod;
- (BOOL)createPath:(NSString *)path;
- (void)refreshChaptersOniPod;
@end


@implementation Controller

+ (void)initialize
{
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	[userDefaults registerDefaults:[NSDictionary dictionaryWithObject:[NSNumber numberWithInt:BPEnglish] forKey:@"Language"]];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication
{
	return YES;
}

- (id)init
{
	if (self = [super init])
	{
		_savedChapters = [[NSMutableArray alloc] init];
		_loadedBibles = [[NSMutableDictionary alloc] init];
	}
	
	return self;
}

- (void)dealloc
{
	[_bible release];
	[_savedChapters release];
	[_loadedBibles release];
	
	[super dealloc];
}

- (void)awakeFromNib
{
	[self changeLanguage:nil];

	[self updatePreview:nil];
	[self refreshChaptersOniPod];
}

- (IBAction)changeLanguage:(id)sender
{
	NSNumber *language = [[NSUserDefaults standardUserDefaults] objectForKey:@"Language"];
	[self loadBibleForLanguage:[language intValue]];
}

- (void)loadBibleForLanguage:(BPLanguage)language
{
	id loadedBible = [_loadedBibles objectForKey:[NSString stringWithFormat:@"%d", language]];
	if (loadedBible != nil)
	{
		_bible = [loadedBible retain];
		[self setupUI];
	}
	else
	{
		[languagePopUp setEnabled:NO];
		[booksPopUp setEnabled:NO];
		[chaptersPopUp setEnabled:NO];
		[copyToiPodButton setEnabled:NO];
		[booksPopUp selectItemAtIndex:-1];
		[chaptersPopUp selectItemAtIndex:-1];
		[progressIndicator setUsesThreadedAnimation:YES];
		[progressIndicator startAnimation:nil];
		
		[NSThread detachNewThreadSelector:@selector(loadXML:) toTarget:self withObject:[NSNumber numberWithInt:language]];
	}
}

- (void)loadXML:(NSNumber *)language
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

	_bible = [[BPBible bibleForLanguage:[language intValue]] retain];
	[_loadedBibles setObject:_bible forKey:[language stringValue]];
	
	[self performSelectorOnMainThread:@selector(setupUI) withObject:nil waitUntilDone:YES];
	
	[pool release];
}

// runs after the bible xml is loaded
- (void)setupUI
{
	[progressIndicator stopAnimation:nil];
	[languagePopUp setEnabled:YES];
	[booksPopUp setEnabled:YES];
	[chaptersPopUp setEnabled:YES];
	[copyToiPodButton setEnabled:YES];
	
	// set books
	NSEnumerator *booksEnum = [[_bible books] objectEnumerator];
	[booksPopUp removeAllItems];
	BPBook *book;
	NSMenuItem *menuItem;
	while (book = [booksEnum nextObject])
	{
		menuItem = [[NSMenuItem alloc] initWithTitle:[book name] action:nil keyEquivalent:@""];
		[menuItem setRepresentedObject:book];
		[[booksPopUp menu] addItem:menuItem];
		[menuItem release];
	}
	[self updateChapters:booksPopUp];
}

- (IBAction)updatePreview:(id)sender
{	
	if ([chaptersPopUp isEnabled] == NO)
	{
		[textView setString:@""];
		[charsField setStringValue:@""];
	}
	else
	{
		BPBook *book = [[booksPopUp selectedItem] representedObject];
		BPChapter *selectedChapter = [[chaptersPopUp selectedItem] representedObject];
		BOOL previewAll = (selectedChapter == nil);
		NSArray *chapters = (previewAll ? [book chapters] : [NSArray arrayWithObject:selectedChapter]);
		NSEnumerator *chaptersEnum = [chapters objectEnumerator]; BPChapter *chapter;
		NSMutableString *str = [NSMutableString string];
		int notes = 0;
		
		while (chapter = [chaptersEnum nextObject])
		{
			NSString *v = [chapter versesFormatted];
			[str appendString:v];
			
			notes += ([v length]/4096+1);
		}
		
		//int notes = [str length]/4096+1;
		[textView setString:(previewAll ? @"No preview available." : str)];
		[textView scrollRangeToVisible:NSMakeRange(0, 1)]; // scroll to top
		[charsField setStringValue:[NSString stringWithFormat:@"%d iPod note%@", notes, (notes != 1 ? @"s" : @"")]];
	}
}

- (IBAction)updateChapters:(id)sender
{
	BPBook *book = [[booksPopUp selectedItem] representedObject];
	NSEnumerator *chaptersEnum = [[book chapters] objectEnumerator];
	BPChapter *chapter;
	NSMenuItem *menuItem;
	int i;
	
	[chaptersPopUp removeAllItems];
	
	menuItem = [[[NSMenuItem alloc] initWithTitle:@"All" action:nil keyEquivalent:@""] autorelease];
	[menuItem setRepresentedObject:nil];
	[[chaptersPopUp menu] addItem:menuItem];
	
	i = 1;
	while (chapter = [chaptersEnum nextObject])
	{
		menuItem = [[NSMenuItem alloc] initWithTitle:[NSString stringWithFormat:@"%d", i++] action:nil keyEquivalent:@""];
		[menuItem setRepresentedObject:chapter];
		[[chaptersPopUp menu] addItem:menuItem];
		[menuItem release];
	}

	[chaptersPopUp selectItemAtIndex:0];
	[self updatePreview:nil];
}

- (IBAction)clearAll:(id)sender
{
	NSString *iPod = [self iPod];

	if (iPod)
	{
		NSString *path = [NSString stringWithFormat:@"%@/Notes/Bible", iPod];
		NSFileManager *manager = [NSFileManager defaultManager];
		
		if ([manager fileExistsAtPath:path])
			[manager removeFileAtPath:path handler:nil];
		
		[self refreshChaptersOniPod];
	}
}

- (IBAction)copyChapterToiPod:(id)sender
{
	[progressIndicator startAnimation:nil];
	
	NSString *iPod = [self iPod];

	if (iPod)
	{
		BPBook *book = [[booksPopUp selectedItem] representedObject];
		BPChapter *selectedChapter = [[chaptersPopUp selectedItem] representedObject];		
		
		if (selectedChapter == nil)
		{
			// get all chapters
			int i;
			for (i=0; i<[book numberOfChapters]; i++)
				[self chapterToiPod:[[book chapters] objectAtIndex:i] book:book];
		}
		else
		{
			// get only selected chapter
			[self chapterToiPod:selectedChapter book:book];
		}
	}
	else
	{
		NSBeginAlertSheet(@"Warning", @"OK", nil, nil, window, self, nil, nil, nil, @"No iPod was found connected to this computer.");
		NSBeep();
	}
	
	[self refreshChaptersOniPod];
	[progressIndicator stopAnimation:nil];
}

- (IBAction)sendFeedback:(id)sender
{
	[[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString:@"mailto:kainjow@kainjow.com?subject=BiblePod%20Feedback"]];
}

- (void)chapterToiPod:(BPChapter *)chapter book:(BPBook *)biblebook
{
	NSString *iPod = [self iPod];

	if (iPod)
	{
		//int l;
		NSString *book = [biblebook name];
		NSArray *verses = [chapter verses];
		
		NSString *path;
		
		//l = [versesFormatted length];
		int i;
		NSMutableString *output = [NSMutableString string];
		NSMutableString *outputWithTitle = [NSMutableString string];
		NSMutableString *prevOutputWithTitle = [NSMutableString string];
		NSString *linxPath = [NSString stringWithFormat:@"%@/Notes/Bible/%@.linx", iPod, book];
		NSString *oldLinx = [NSString stringWithContentsOfFile:linxPath];
		NSMutableString *linx = [NSMutableString string];
		NSString *linxTitle = [NSString stringWithFormat:@"<title>%@</title>", book];
		int startv=1;
		
		// add title if it doesn't exist
		if (oldLinx)
			[linx setString:oldLinx];
		if (![linx hasPrefix:linxTitle])
			[linx appendString:linxTitle];
		
		for (i=0; i<[verses count]+1; i++)
		{
			BPVerse *verse = [verses objectAtIndex:i];
			NSString *proposed, *name, *filename, *verseText;

			// build name so it's nicely formatted and sorted
			name = [NSString stringWithFormat:@"%d:%d-%d", [chapter chapterNumber], startv, i];
			filename = [NSString stringWithFormat:@"%@!%d%d", book, [chapter chapterNumber], i]; 
			
			if (i+1==startv)
				[output setString:@""];
			
			if (i<[verses count])
			{
				verseText = [NSString stringWithFormat:@"[%d] %@\r\r", i+1, [verse text]];
				proposed = [NSString stringWithFormat:@"%@%@", output, verseText];
			}
			else
				proposed = output;
			
			[outputWithTitle setString:[NSString stringWithFormat:@"<title>%@</title>%@", name, proposed]];
			[prevOutputWithTitle setString:[NSString stringWithFormat:@"<title>%@</title>%@", name, output]];
			
			if ([outputWithTitle length]>4096 || i==[verses count]) { // new length is too long, use old length
				path = [NSString stringWithFormat:@"%@/Notes/Bible/files/%@", iPod, filename];
				
				if ([self createPath:[path stringByDeletingLastPathComponent]])
				{
					[[prevOutputWithTitle stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] writeToFile:path atomically:YES];
					
					[linx appendFormat:@"<a href=\"files/%@\">%@</a>\r", filename, name];
				}
				
				[output setString:verseText];
				startv=i+1;
			}
			else
				[output setString:proposed];
		}
		
		// write out .linx file
		[linx writeToFile:linxPath atomically:YES];
	}
}

- (NSString *)iPod
{
    NSArray *allVolumes = [[NSWorkspace sharedWorkspace] mountedRemovableMedia];
    int i;
    for (i=0;i<[allVolumes count];i++)
    {
        NSString *iPodControlPath = [[allVolumes objectAtIndex:i] stringByAppendingPathComponent:@"iPod_Control"];
        if ([[NSFileManager defaultManager] fileExistsAtPath:iPodControlPath]) return [allVolumes objectAtIndex:i];
    }
    
    return nil;
}

- (int)notesOniPod
{
	NSString *iPod = [self iPod];
	
	if (iPod != nil) {
		NSString *path = [iPod stringByAppendingPathComponent:@"Notes"];
		NSFileManager *manager = [NSFileManager defaultManager];
		BOOL isDir;
		int count=0;
		
		if ([manager fileExistsAtPath:path isDirectory:&isDir] && isDir) {
			NSArray *subpaths = [manager subpathsAtPath:path];
			NSEnumerator *e = [subpaths objectEnumerator];
			NSString *file;
			
			while (file = [e nextObject]) {
				NSString *fullPath = [path stringByAppendingPathComponent:file];
				NSString *filename = [file lastPathComponent];
				if ([manager fileExistsAtPath:fullPath isDirectory:&isDir] && !isDir) {
					if (![filename hasPrefix:@"."]) {
						count++;
					}
				}
			}
			
			return count;
		}
	}
	
	return 0;
}

- (BOOL)createPath:(NSString *)path
{
	// from Pod2Go
    NSMutableString *s = [NSMutableString string];
    NSArray *paths = [path pathComponents];
    int i;
    BOOL dir;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    for (i=0; i<[paths count]; i++) {
        [s setString:[s stringByAppendingPathComponent:[paths objectAtIndex:i]]];
        if (![fileManager fileExistsAtPath:s isDirectory:&dir])
            [fileManager createDirectoryAtPath:s attributes:nil];
    }
    
    if ([fileManager fileExistsAtPath:s isDirectory:&dir])
        return YES;
    
    return NO;
}

- (void)refreshChaptersOniPod
{
	NSString *iPod = [self iPod];
	
	[_savedChapters removeAllObjects];
	
	if (iPod) {
		NSString *path = [iPod stringByAppendingPathComponent:@"/Notes/Bible/files"];
		NSArray *b = [[NSFileManager defaultManager] directoryContentsAtPath:path];
		int i;
		
		for (i=0; i<[b count]; i++) {
			NSString *filename = [b objectAtIndex:i];
			if (![filename hasPrefix:@"."]) {
				NSMutableDictionary *d = [NSMutableDictionary dictionary];
				NSArray *split = [filename componentsSeparatedByString:@"!"];
				NSString *text = [[NSString alloc] initWithContentsOfFile:[path stringByAppendingPathComponent:filename]];
				NSString *title = [[[[text componentsSeparatedByString:@"<title>"] objectAtIndex:1] componentsSeparatedByString:@"</title>"] objectAtIndex:0];
				
				[d setObject:[NSString stringWithFormat:@"%@ %@", [split objectAtIndex:0], title] forKey:@"name"];
				[_savedChapters addObject:d];
				
				[text release];
			}
		}
	}
	
	[savedTableView reloadData];
}

- (int)numberOfRowsInTableView:(NSTableView *)aTableView
{
    return [_savedChapters count];
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex
{
	return [[_savedChapters objectAtIndex:rowIndex] objectForKey:@"name"];
}

- (BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex
{
	// no selection allowed
	return NO;
}

@end
