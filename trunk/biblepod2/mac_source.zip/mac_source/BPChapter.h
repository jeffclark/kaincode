//
//  BPChapter.h
//  BiblePod
//
//  Created by Kevin Wojniak on 8/30/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "BPBibleObject.h"


@interface BPChapter : BPBibleObject
{
	NSMutableArray *_verses;
	int _chapterNumber;
}

+ (id)chapter;
- (NSMutableArray *)verses;
- (int)chapterNumber;
- (NSString *)versesFormatted;

- (void)_setChapterNumber:(int)chapterNumber;

@end
