//
//  Bible.h
//  BiblePod
//
//  Created by Kevin Wojniak on Sun Apr 04 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BPBook;


typedef enum
{
	BPEnglish,
	BPSpanish,
} BPLanguage;


@interface BPBible : NSObject
{
	NSArray *_books;
}

+ (id)bibleForLanguage:(BPLanguage)language;
- (id)initWithLanguage:(BPLanguage)language;

- (NSArray *)books;
- (BPBook *)bookNamed:(NSString *)name;

@end
