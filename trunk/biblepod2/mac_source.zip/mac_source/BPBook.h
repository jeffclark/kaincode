//
//  BibleBook.h
//  BiblePod
//
//  Created by Kevin Wojniak on Sun Apr 04 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BPBibleObject.h"

@interface BPBook : BPBibleObject
{
	NSString *_name;
	int _bookNumber;
	NSMutableArray *_chapters;
}

+ (id)bookWithName:(NSString *)bname;
- (id)initWithName:bname;

- (NSString *)name;
- (int)bookNumber;

- (NSMutableArray *)chapters;
- (int)numberOfChapters;


- (void)_setBookNumber:(int)bookNumber;

- (NSComparisonResult)compare:(id)anotherBook;

@end
