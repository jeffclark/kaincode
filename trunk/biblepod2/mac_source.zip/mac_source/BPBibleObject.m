//
//  BPBibleObject.m
//  BiblePod
//
//  Created by Kevin Wojniak on 8/30/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "BPBibleObject.h"
#import "BPBible.h"


@implementation BPBibleObject

- (BPBible *)bible
{
	return _bible;
}

- (void)_setBible:(BPBible *)bible
{
	_bible = bible;
}

@end
