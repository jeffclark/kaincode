//
//  Bible.m
//  BiblePod
//
//  Created by Kevin Wojniak on Sun Apr 04 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import "BPBible.h"
#import "BPBook.h"
#import "BPChapter.h"
#import "BPVerse.h"


@interface BPBible (priv)
- (void)_loadLanguage:(BPLanguage)language;

@end


@implementation BPBible

+ (id)bibleForLanguage:(BPLanguage)language
{
	return [[[self alloc] initWithLanguage:language] autorelease];
}

- (id)initWithLanguage:(BPLanguage)language
{
	if (self = [super init])
	{
		[self _loadLanguage:language];
	}
	
	return self;
}

- (void)dealloc
{
	[_books release];
	[super dealloc];
}

- (void)_loadLanguage:(BPLanguage)language
{
	NSMutableArray *books = [NSMutableArray array];
	NSXMLDocument *bibleXML = nil; NSXMLElement *rootXML = nil;
	NSArray *booksXML = nil; NSEnumerator *booksEnum = nil; NSXMLElement *bookXML = nil;
	NSArray *chaptersXML = nil; NSEnumerator *chaptersEnum = nil; NSXMLElement *chapterXML = nil;
	NSArray *versesXML = nil; NSEnumerator *versesEnum = nil; NSXMLElement *verseXML = nil;
	NSString *fileName = nil;
	
	switch (language)
	{
		case BPEnglish:
			fileName = @"KJV_apok";
			break;
		case BPSpanish:
			fileName = @"spanish_sev";
			break;
	}
	
	bibleXML = [[NSXMLDocument alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:fileName ofType:@"xml"]] options:0 error:nil];
	rootXML = [bibleXML rootElement]; // XMLBIBLE
	booksXML = [rootXML elementsForName:@"BIBLEBOOK"];
	booksEnum = [booksXML objectEnumerator];
	while (bookXML = [booksEnum nextObject])
	{
		int bookNumber = [(NSNumber *)[[bookXML attributeForName:@"bnumber"] objectValue] intValue];
		if (bookNumber > 66) // 66 is Revelation
			continue;
		
		BPBook *bibleBook = [BPBook bookWithName:[[bookXML attributeForName:@"bname"] stringValue]];
		[bibleBook _setBookNumber:bookNumber];
		
		chaptersXML = [bookXML elementsForName:@"CHAPTER"];
		chaptersEnum = [chaptersXML objectEnumerator];
		while (chapterXML = [chaptersEnum nextObject])
		{
			BPChapter *chapter = [BPChapter chapter];
			[chapter _setChapterNumber:[[[chapterXML attributeForName:@"cnumber"] objectValue] intValue]];
			
			versesXML = [chapterXML elementsForName:@"VERS"];
			versesEnum = [versesXML objectEnumerator];
			while (verseXML = [versesEnum nextObject])
			{
				BPVerse *verse = [[BPVerse alloc] init];
				NSMutableString *verseText = [NSMutableString stringWithString:[verseXML stringValue]];
				[verseText replaceOccurrencesOfString:@"<I>" withString:@"" options:0 range:NSMakeRange(0, [verseText length])];
				[verseText replaceOccurrencesOfString:@"</I>" withString:@"" options:0 range:NSMakeRange(0, [verseText length])];
				[verse _setText:verseText];
				[[chapter verses] addObject:verse];
				[verse release];
			}
			[[bibleBook chapters] addObject:chapter];
		}

		[books addObject:bibleBook];
	}

	/*[bbooks sortUsingFunction:sortnum context:nil];

	for (i=0; i<[bbooks count]; i++) {
		[bbooks replaceObjectAtIndex:i withObject:[[bbooks objectAtIndex:i] objectForKey:@"bibleBook"]];
	}*/

	_books = [books retain];
}

- (NSArray *)books
{
	return _books;
}

- (BPBook *)bookNamed:(NSString *)name
{
	NSArray *books = [NSArray arrayWithArray:[self books]];
	int i;
	for (i=0; i<[books count]; i++) {
		if ([[[books objectAtIndex:i] name] isEqualToString:name]) {
			return [books objectAtIndex:i];
		}
	}
	return nil;
}

@end
