/* Controller */

#import <Cocoa/Cocoa.h>

@class BPBible;

@interface Controller : NSObject
{
	IBOutlet NSPopUpButton *languagePopUp, *booksPopUp, *chaptersPopUp;
	IBOutlet NSTextView *textView;
	IBOutlet NSTextField *charsField;
	IBOutlet NSTableView *savedTableView;
	IBOutlet NSButton *copyToiPodButton;
	IBOutlet NSWindow *window;
	IBOutlet NSProgressIndicator *progressIndicator;

	BPBible *_bible;
	NSMutableDictionary *_loadedBibles;
	NSMutableArray *_savedChapters;
}

- (IBAction)changeLanguage:(id)sender;
- (IBAction)updatePreview:(id)sender;
- (IBAction)updateChapters:(id)sender;
- (IBAction)clearAll:(id)sender;
- (IBAction)copyChapterToiPod:(id)sender;

- (IBAction)sendFeedback:(id)sender;

@end
