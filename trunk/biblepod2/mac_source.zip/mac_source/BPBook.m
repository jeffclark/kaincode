//
//  BibleBook.m
//  BiblePod
//
//  Created by Kevin Wojniak on Sun Apr 04 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import "BPBook.h"


@implementation BPBook

+ (id)bookWithName:(NSString *)bname
{
	return [[[self alloc] initWithName:bname] autorelease];
}

- (id)initWithName:bname
{
	if (self = [super init])
	{
		_name = [bname copy];
		_chapters = [[NSMutableArray alloc] init];
	}
	
	return self;
}

- (void)dealloc
{
	[_name release];
	[_chapters release];
	[super dealloc];
}

- (NSString *)name
{
	return _name;
}

- (int)bookNumber
{
	return _bookNumber;
}

- (NSMutableArray *)chapters
{
	return _chapters;
}

- (int)numberOfChapters
{
	return [[self chapters] count];
}

- (void)_setBookNumber:(int)bookNumber
{
	_bookNumber = bookNumber;
}

- (NSComparisonResult)compare:(id)anotherBook
{
	if ([self bookNumber] < [anotherBook bookNumber])
		return NSOrderedAscending;
	else if ([self bookNumber] > [anotherBook bookNumber])
		return NSOrderedDescending;
	return NSOrderedSame;
}

@end
