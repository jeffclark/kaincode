//
//  BPChapter.m
//  BiblePod
//
//  Created by Kevin Wojniak on 8/30/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "BPChapter.h"
#import "BPVerse.h"


@implementation BPChapter

+ (id)chapter
{
	return [[[self alloc] init] autorelease];
}

- (id)init
{
	if (self = [super init])
	{
		_verses = [[NSMutableArray alloc] init];
	}
	
	return self;
}

- (void)dealloc
{
	[_verses release];
	[super dealloc];
}

- (NSMutableArray *)verses
{
	return _verses;
}

- (int)chapterNumber
{
	return _chapterNumber;
}

- (NSString *)versesFormatted
{
	NSMutableString *str = [NSMutableString string];
	NSEnumerator *versesEnum = [[self verses] objectEnumerator];
	BPVerse *verse;
	int i = 1;
	while (verse = [versesEnum nextObject])
		[str appendFormat:@"[%d] %@%@", i++, [verse text], (i < [[self verses] count] ? @"\r\r" : @"")];
	return [[str copy] autorelease];
}

- (void)_setChapterNumber:(int)chapterNumber
{
	_chapterNumber = chapterNumber;
}

@end
