//
//  BPVerse.m
//  BiblePod
//
//  Created by Kevin Wojniak on 8/30/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "BPVerse.h"

@implementation BPVerse

- (void)dealloc
{
	[_text release];
	[super dealloc];
}

- (NSString *)text
{
	return _text;
}

- (void)_setText:(NSString *)text
{
	if (_text != text)
	{
		[_text release];
		_text = [text copy];
	}
}

@end
