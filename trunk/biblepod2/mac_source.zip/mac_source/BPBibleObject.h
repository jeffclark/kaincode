//
//  BPBibleObject.h
//  BiblePod
//
//  Created by Kevin Wojniak on 8/30/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class BPBible;

@interface BPBibleObject : NSObject
{
	BPBible *_bible;
}

- (BPBible *)bible;
- (void)_setBible:(BPBible *)bible;

@end
