//
//  BPVerse.h
//  BiblePod
//
//  Created by Kevin Wojniak on 8/30/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "BPBibleObject.h"


@interface BPVerse : BPBibleObject
{
	NSString *_text;
}

- (NSString *)text;
- (void)_setText:(NSString *)text;

@end
